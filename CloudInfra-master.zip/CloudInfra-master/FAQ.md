# Frequently Asked Questions (FAQ)

This document serves to help clarify, point to, and address some common questions about the CloudInfra repository.

## How do I get access to a specific AWS IAM role via SAML SSO?

See [aws-assume-role-workflow.md](./docs/aws-assume-role-workflow.md#Pre-Reqs) pre-reqs section.

## How do I assume roles, if I initially logged in via SAML SSO?

- See [Console workflow](./docs/aws-assume-role-workflow.md#Console-GUI-Access) in `aws-assume-role-workflow.md`
- See [CLI workflow](./docs/aws-assume-role-workflow.md#CLI-Access) in `aws-assume-role-workflow.md`

## How can I get my PR approved?

See [APPROVING.md](./APPROVING.md)

## Who can approve my PR?

See [CONTRIBUTING.md](./CONTRIBUTING.md)

## Why can't I merge my own PRs?

See [APPROVING.md](./APPROVING.md)

## How can I have the ability to merge PRs?

See [APPROVING.md](./APPROVING.md)

## How do I contribute to the repo?

See [CONTRIBUTING.md](./CONTRIBUTING.md)

## Where are the release notes?

See [CHANGELOG.md](./CHANGELOG.md)

## Why am I getting a merge conflict in my PR?

Generally this happens because `master` has new changes in files you are modifying. **Rebasing** generally resolves this.
- [Doc Link](./docs/contributing/rebasing.md)

## How do I rebase?

[Rebase Documentation](./docs/contributing/rebasing.md)

## How do I request a change promotion?

See the [PR Template](./.github/pull_request_template.md) for details

## How will I know when my changes are promoted?

See the [RELEASE.md](./RELEASE.md#Overview) for details

## How can I get my changes promoted?

See [RELEASE.md](./RELEASE.md#promotion-types)

## How do I invoke the CI for Lambda building?

See the [awslambda README](./awslambda/README.md#cicd-usage) for details

## How do I invoke the CI for Packer building?

See [packer doc](./docs/packer/packer-development.md#building) for details

## How do I invoke the CI for Atlantis usage?

See the [terraform development doc](./docs/terraform/terraform-development-v2.md).

## Why am I getting a diff in the GileadSSO resource for the IDM provider?

It is a high chance that Terraform is formatting the SAML doc differently than what is currently up in state. This diff can be safely **ignored**.

## Atlantis: How can I add to my root's terraform.tfvars?

See [here](./docs/atlantis/atlantis-workflow.md#terraformautotfvars)

## Atlantis: How can I add an external file (i.e. SAML doc) for Atlantis to use?

See [here](./docs/atlantis/atlantis-workflow.md#external-files-for-terraform)

## Atlantis: How do I tell Atlantis to specify a different workflow? It's not reading my external file

See [here](./docs/atlantis/atlantis-workflow.md#external-files-for-terraform)

## Atlantis error: No value for required variable

### Example

```
Did not find any parameters at /atlantis/env/tst/shared-services/ap-southeast-2/terraform_tfvars, proceeding without using a tfvars file.

Error: No value for required variable

  on variables.tf line 69:
  69: variable "rds_password" {

The root module input variable "rds_password" is not set, and has no default
value. Use a -var or -var-file command line argument to provide a value for
this variable.
```

Any variables that do not have a default value in Terraform, Atlantis will fail. One needs to **place the `terraform.tfvars` in SSM** to resolve this.
- [Doc Link](./docs/atlantis/atlantis-workflow.md)

## Atlantis error: no file exists at XXX

### Example

```
Error: Error in function call

  on cognito.tf line 114, in resource "aws_cognito_identity_provider" "hivaustralia":
 114:     "MetadataFile"          = file("idp_ping_metadata.xml")

Call to function "file" failed: no file exists at idp_ping_metadata.xml.
```

This is a similar problem to the error above, but occurs because Atlantis doesn't see this file. In most cases, this can be resolved by **putting said file in SSM**.
- [Doc Link](./docs/atlantis/atlantis-workflow.md)

## Atlantis error: The role XXXX cannot be assumed

### Example

```
Initializing the backend...

Error: The role "arn:aws:iam::676285524611:role/devopsbot" cannot be assumed.

  There are a number of possible causes of this - the most common are:
    * The credentials used in order to assume the role are invalid
    * The credentials do not have appropriate permission to assume the role
    * The role ARN is not valid
```

The devops-role-bootstrap lambda will automatically set up every account with the roles and permissions Atlantis needs. If you get this error, it means that this lambda has not been run for that account for some reason. It can be resolved by submitting a Sparc ticket requesting that this function be run for the account in question.

## How can I enable Atlantis in a root?
- [Atlantis Configuration Documentation](./docs/atlantis/atlantis-config-deployment.md#enabling-tf-roots-for-atlantis)

## Atlantis error: No space left on device

### Example

```
Upgrading modules...

Error: failed to create local modules directory: mkdir .terraform: no space left on device
```

Atlantis is out of disk space due to a concurrent PR touching numerous PRs (usually the release PR). Currently, the only resolution is to have said PR recommit  and waiting for Atlantis to free up space.
- To determine if Atlantis is ready to be used, check if an Atlantis job can be seen in the CI test section of a PR (near the merge button)

## I need general help / I have questions that are not covered here

1. Check the `docs/` to see if your question is answered there
1. Visit our team's *WIO Office Hours* which is **weekly on Fridays from 10am - 11am**. Please ask any of the Nebulaworks team members for the meeting link.
