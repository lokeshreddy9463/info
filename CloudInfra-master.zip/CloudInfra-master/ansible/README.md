# Ansible


## Table of Contents
* [Wordpress Deployment](./roles/wordpress/README.md)

## Directory Layout
1. Each team/project will have its own playbook
2. The concept of "roles" in ansible is different from how we are defining the function of the machine we are deploying. Roles in ansible are related tasks grouped together, whereas we have defined the term "component" to represent what our machine is going to function as.
3. Our roles will live under the `roles` directory. Each team is responsible for maintaining their own roles or creating roles that will be leveraged in their playbooks.

## Playbook Setup
1. Playbook file should be named with the following format `playbook-<PROJECT_NAME>.yml`
2. This file is then used in the ansible bootstrap script with the following command

    ```
    ansible-playbook --connection=local $REPOPATH/ansible/playbook-$PROJECT.yml --tags $COMPONENT
    ```
3. Inside the playbook files, you will see a parameter called `roles`. Inside this parameter, it will have a `role` and `tags` defined.  The role is to specify which role under the `roles` directory we will be using, and the tags are defined to dictate which roles will be ran.  The tags are reflective of the `component` tag of the EC2 instance.

## How to use `run-ansible.sh` file
1. EC2 Instance must at least be tagged with the following keys:
  - environment
  - project
  - component (maps to ansible role)
  - workspace
  - Name
  - gxp
  - terraform
2. SSH key that allows the EC2 instance to clone down the repo must be put into AWS parameter store beforehand
