# Ansible Role: Fluent Bit
Installs [Fluent Bit](https://fluentbit.io/) (td-agent-bit) on Debian/Ubuntu.

## Requirements

CloudWatch Logs plugin for Fluent Bit: https://github.com/aws/amazon-cloudwatch-logs-for-fluent-bit
- Currently we are downloading the cloudwatch.so binary from the s3 bucket: gilead-aws-devops-artifacts insteading of building the project.
- In order to extract the binary, pull the docker image `docker pull amazon/aws-for-fluent-bit:2.4.0` and exec inside the container. Copy the binary from the container to your host machine and then push to s3.

## Role Variables

Available variables are listed below, along with default values (see `defaults/main.yml`):

  - fluentbit_service_flush_seconds: 5
  - fluentbit_service_daemon: false
  - fluentbit_service_custom_parsers_file: []
  - fluentbit_service_log_level: info
  - fluentbit_service_enable_metrics: false
  - fluentbit_service_metrics_listen_ip: 0.0.0.0
  - fluentbit_service_metrics_listen_port: 2020
  - fluentbit_inputs: []
  - fluentbit_outputs: []
  - fluentbit_additional_conf_files: []

## Dependencies

None.

## Example Playbook

    - hosts: ec2-instances
      roles:
        - fluentbit
