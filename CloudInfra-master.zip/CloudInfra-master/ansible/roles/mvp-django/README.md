## Django + New Relic MVP deployment

This directory contains an ansible role to automate the deployment of Django and
integration with Newrelic.

#### Notes

You will find there is a newrelic license key that is retreived using a lookup
function. This licensekey is currently stored in AWS Parameter Store.

Use your appropriate AWS credentials within the Shared DevOps Account to access
the license key within AWS Systems Manager Parameter store under
`/newrelicpoc/licensekey`
