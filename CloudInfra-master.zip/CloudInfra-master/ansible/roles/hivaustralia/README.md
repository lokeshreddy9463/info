# HIVAustrailia Ansible role
This is the role that is used to configure a Wordpress service for HIVAustrailia.

## Troubleshooting
> I can't seem to change the callback URL in the settings page on the Wordpress Dashboard!

This is a licensing limitation in that we cannot change the value in there, even when we updated the infrastructure stack. To get around this, the only way right now is to update the terraform configuration with the correct information and redeploy the instance back up.