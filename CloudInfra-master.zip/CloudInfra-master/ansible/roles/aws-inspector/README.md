# Ansible Role: AWS Inspector
Installs [AWS Inspector](https://aws.amazon.com/inspector/) (awsagent) on RedHat/CentOS or Debian/Ubuntu.

## Requirements

None.

## Role Variables

Available variables are listed below, along with default values (see `defaults/main.yml`):

    aws_inspector_url: "https://d1wk0tztpsntt1.cloudfront.net/linux/latest/install"
    aws_inspector_installer_dest: /tmp/aws_inspector_agent_installer

URL from which inspector installer will be downloaded, and temporary directory where installer will be stored.

    awsagent_state: started
    awsagent_enabled: true

Control the `awsagent` service; by default, for Amazon Inspector to work correctly, you must have `awsagent` running on any server you want inspected.

There is also a handler, `restart awsagent`, which can be used to restart the agent.
## Dependencies

None.

## Example Playbook

    - hosts: ec2-instances
      roles:
        - aws-inspector
