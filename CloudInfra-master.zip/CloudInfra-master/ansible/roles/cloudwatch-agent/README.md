# Ansible Role: AWS CloudWatch Agent
Installs [AWS CloudWatch Agent](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/WhatIsCloudWatch.html) (amazon-cloudwatch-agent-ctl ) on Debian/Ubuntu.

## Requirements

None.

## Role Variables

Available variables are listed below, along with default values (see `defaults/main.yml` and `vars/main.yml`):

    cwa_conf_json_file_content: ""
    cwa_agent_mode: "ec2"
    cwa_aws_region: ""
    cwa_use_credentials: false
    cwa_profile: "AmazonCloudWatchAgent"
    cwa_agent_profile_path: /root
    cwa_http_proxy: ""
    cwa_https_proxy: ""
    cwa_no_proxy: "169.254.169.254"
    cwa_logrotate_file_size: "10M"
    cwa_logrotate_files: 5
    cwa_package: amazon-cloudwatch-agent
    cwa_install_path: /opt/aws/amazon-cloudwatch-agent
    cwa_agent_ctl: /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl
    cwa_package_gpg: https://s3.amazonaws.com/amazoncloudwatch-agent/assets/amazon-cloudwatch-agent.gpg
    cwa_package_gpg_id: D58167303B789C72

## Dependencies

None.

## Example Playbook

    - hosts: ec2-instances
      roles:
        - cloudwatch-agent
