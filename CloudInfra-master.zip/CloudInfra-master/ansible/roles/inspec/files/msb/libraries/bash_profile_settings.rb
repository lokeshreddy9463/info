class UmaskValue
  def initialize(umask_value)
    @umask ||= umask_value[-3..]
  end

  def more_permissive_than?(target_mask)
    if target_mask.is_a? Integer
      target_mask = target_mask.to_s(8)[-3..]
    end
    @umask.each_char.zip(target_mask.each_char).any? {|a, b| a < b}
  end
end

class BashProfileSettings < Inspec.resource(1)
  name "bash_profile_settings"

  desc "Describe a user's bash profile"

  example <<~EOT.chomp
    describe dir_listing("/var/log") do
      its("owner") { should eq("root") }
    end
  EOT

  def initialize(settings_file)
    @settings_file = settings_file
  end

  def umask
    umask_values = profile_contents.each_line.filter_map do |line|
      line.match(/^\s*umask\s+([0-9]+)/)
    end.map do |match|
      match[1]
    end
    puts("#{self} umasks #{umask_values}")
    UmaskValue.new(umask_values.last)
  end

  def profile_contents
    File.open(@settings_file).read
  end

  def inspect
    "bash profile settings #{@settings_file}"
  end

  def to_s
    inspect
  end
end

class EnvPath < Inspec.resource(1)
  name 'env_path'

  desc "Describe the current PATH"

  attr_reader :components

  def initialize
    path = inspec.os_env("PATH").content
    @components ||= path.split(":")
  end

  def has_component?(comp)
    @components.any? {|c| c == comp }
  end

  def has_component_matching?(pattern)
    @components.any? {|c| c.match pattern }
  end
end
