require "etc"

class CompoundProperty
  # This class allows a rule to be applied to a collection of values as a whole
  def initialize(values)
    @values ||= values.uniq
  end

  [:==, :!=, :<, :>, :<=, :>=].each do |op|
    define_method(op) do |other|
      @values.all? {|v| v.send(op, other) }
    end
  end

  def &(other)
    self.class.new(@values.map {|v| v & other })
  end

  def inspect
    if @values.count == 1
      @values.first.inspect
    else
      @values.inspect
    end
  end

  def more_permissive_than?(target_mode)
    # if target_mode.is_a? String
    #   target_mode = target_mode.to_i(8)
    # end
    # mode_mask = target_mode ^ 0777
    # self.to_i & mode_mask != 0
    if target_mode.is_a? Integer
      target_mode = target_mode.to_s(8)[-3..]
    end
    modes = @values.map {|v| v.to_i.to_s(8)[3..]}
    modes.any? do |mode|
      mode.each_char.zip(target_mode.each_char).any? {|a, b| a > b}
    end
  end

  def less_permissive_than?(target_mode)
    if target_mode.is_a? Integer
      target_mode = target_mode.to_s(8)[-3..]
    end
    modes = @values.map {|v| v.to_i.to_s(8)[3..]}
    modes.any? do |mode|
      mode.each_char.zip(target_mode.each_char).any? {|a, b| a < b}
    end
  end

  def to_s
    inspect
  end

  def to_i
    if @values.count == 1
      @values[0].to_i
    else
      @values
    end
  end
end

module MultipleFileResource
  # This mixin implements the behavior of the file resource for lists of files
  # The class including this must implement `file_names`
  def owner
    get_stats do |entry|
      begin
        Etc.getpwuid(entry.uid).name
      rescue ArgumentError
        entry.uid
      end
    end
  end

  def group
    get_stats do |entry|
      begin
        Etc.getgrgid(entry.gid).name
      rescue ArgumentError
        entry.gid
      end
    end
  end

  def mode
    get_stats {|entry| entry.mode & 0777 }
  end

  def root_owned?
    owner == "root" and group == "root"
  end

  def world_writable?
    exists? and mode & 02 == 0
  end

  def world_readable?
    exists? and mode & 04 == 0
  end

  def exists?
    !file_names.empty?
  end

  def more_permissive_than?(target_mode)
    exists? and mode.more_permissive_than? target_mode
  end

  def less_permissive_than?(target_mode)
    exists? and mode.less_permissive_than? target_mode
  end

  private

  def get_compound(&block)
    CompoundProperty.new(file_names.map &block)
  end

  def get_stats(&block)
    @file_stats = file_names.map {|name| File.stat(name) }
    CompoundProperty.new(@file_stats.map &block)
  end
end

class DirListing < Inspec.resource(1)
  name "dir_listing"

  desc "Describe all the files in a directory"

  example <<~EOT.chomp
    describe dir_listing("/var/log") do
      its("owner") { should eq("root") }
    end
  EOT

  include MultipleFileResource
  
  def initialize(path, recursive=true)
    @path ||= path
    @recursive ||= recursive
  end

  def file_names
    @entries ||= Dir.glob(@recursive ? "#{@path}/**/*" : "#{@path}/*")
  end

  def to_s
    recursive_part = @recursive ? "(recursive)" : nil
    base = "Files in directory #{@path}"
    count = "[#{file_names.count} found]"
    [base, recursive_part, count].compact.join(" ")
  end
end

class FilesGlob < Inspec.resource(1)
  name "files_glob"

  desc "Describe all files matching a glob pattern"

  example <<~EOT.chomp
    describe files_glob("/etc/*cron*") do
      its("owner") { should eq("root") }
    end
  EOT

  include MultipleFileResource

  def initialize(pattern)
    @pattern ||= pattern
  end

  def file_names
    @entries ||= Dir.glob(@pattern)
  end

  def to_s
    "Files matching pattern #{@pattern} [#{file_names.count} matched]"
  end
end

class FileList < Inspec.resource(1)
  name "file_list"

  desc "Describe all files in a list"

  example <<~EOT.chomp
    describe files_glob("/etc/*cron*") do
      its("owner") { should eq("root") }
    end
  EOT

  include MultipleFileResource

  def initialize(*file_paths)
    if file_paths.count == 1 and file_paths[0].respond_to? :each
      @file_paths ||= file_paths[0]
    else
      @file_paths ||= file_paths
    end
  end

  def file_names
    @file_paths
  end

  def to_s
    file_list = @file_paths.join(", ")
    "Files #{file_list}"
  end
end
