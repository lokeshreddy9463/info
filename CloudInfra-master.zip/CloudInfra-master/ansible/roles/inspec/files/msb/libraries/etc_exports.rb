class EtcExports < Inspec.resource(1)
  name "etc_exports"

  desc "Describe the entries in /etc/exports"

  example <<~EOT.chomp
    describe etc_exports do
      its("exports.uniq") { should include "some_directory" }
    end
  EOT

  attr_accessor :params

  def initialize(file_path="/etc/exports")
    @file_path = file_path
    @params = export_lines.map {|line| line.split[0] }
  end

  filter = FilterTable.create
  filter.register_column(:exports, field: "export")
  filter.install_filter_methods_on_resource(self, :params)
  
  def export_lines
    @export_lines ||= File.new(@file_path).each_line.map(&:strip).reject {|line| line.start_with? "#" or line.blank? }
  end
end
