%w(/ /var /home).each.with_index do |path, index|
  control "5.1.1.#{index + 1}" do
    title "Is separate partition created for #{path}?"
    describe mount(path) do
      it { should be_mounted }
    end
  end
end

control "5.3.1.01" do
  title "Do appropriate local filesystems have nodev option?"

  describe mount("/home") do
    its("options") { should include "nodev" }
  end
  describe mount("/var") do
    its("options") { should include "nodev" }
  end
end

control "5.3.1.02" do
  title "Does removable media have nosuid and nodev and noexec options?"
  only_if { false }  # no removable media to check

  describe command("/bin/false") do
    its("exit_status") { should eq 0 }
  end
end

control "5.3.1.03A" do
  title "Is noexec option set for /tmp?"

  describe mount("/tmp") do
    its("options") { should include "noexec" }
  end
end

control "5.3.2.01" do
  title "Are console user removable filesystem permissions restricted?"
  only_if { false }  # no removable media to check

  describe command("/bin/false") do
    its("options") { should include "nodev" }
  end
end
