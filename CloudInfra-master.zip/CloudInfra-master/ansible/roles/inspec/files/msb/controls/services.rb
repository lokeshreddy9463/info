enabled_services = {
  "5.2.2" => "auditd",
  "5.2.A.01" => "crond"

}

disabled_services = {
  "5.2.1.2" => "sendmail",
  "5.2.1.5" => "smb",
  "5.2.1.6" => "snmp",
  "5.2.A.02" => "hplip",
  "5.2.A.03" => "portmap",
  "5.2.A.04" => "apmd",
  "5.2.A.05" => "isdn",
  "5.2.A.06" => "readahead_early",
  "5.2.A.07" => "autofs",
  "5.2.A.08" => "kdump",
  "5.2.A.09" => "readahead_later",
  "5.2.A.10" => "avahi-daemon",
  "5.2.A.11" => "kudzu",
  "5.2.A.13" => "bluetooth",
  "5.2.A.14" => "mcstrans",
  "5.2.A.15" => "rpcgssd",
  "5.2.A.16 and 5.2.C.05" => "cups",
  "5.2.A.17" => "mdmonitor",
  "5.2.A.18" => "rpcidmapd",
  "5.2.A.21" => "setroubleshoot",
  "5.2.A.22" => "ftp",
  "5.2.A.23" => "microcode_ctl",
  "5.2.A.24" => "xfs",
  "5.2.A.25" => "gpm",
  "5.2.A.27" => "yum-updatesd",
  "5.2.A.30" => "hidd",
  "5.2.A.31" => "pcscd",
  "5.2.B.01" => "inetd",
  "5.2.B.02" => "rlogin",
  "5.2.B.03" => "telnet",
  "5.2.B.04" => "ypserv",
  "5.2.B.05" => "rsh",
  "5.2.B.06" => "tftp",
  "5.2.B.07" => "rcp",
  "5.2.B.08" => "talk",
  "5.2.B.09" => "xinetd",
  "5.2.C.01" => "avahi-dnsconfd",
  "5.2.C.02" => "dns",
  "5.2.C.03" => "apache2",
  "5.2.C.04" => "dhcpd",
}

disabled_services.each do |control_name, service_name|
  control control_name do
    title "Is #{service_name} disabled?"
    describe service(service_name) do
      it { should_not be_running }
    end
  end
end

enabled_services.each do |control_name, service_name|
  control control_name do
    title "Is #{service_name} enabled?"
    describe service(service_name) do
      it { should be_running }
    end
  end
end

control "5.3.2.03" do
  title "Disable modprobe loading of USB storage driver?"
  only_if("There are no USB ports on an EC2 instance") { false }
  describe kernel_module("usb-storage") do
    it { should be_disabled }
  end
end

control "5.3.2.07" do
  title "Disable mounting of uncommon file system types (e.g. cramfs)"
  disabled_modules = %w(
        cramfs
        freevxfs
        jffs2
        hfs
        hfsplus
        squashfs
        vfat
        udf
    )
    disabled_modules.each do |mod_name|
      describe kernel_module(mod_name) do
        it { should be_disabled }
      end
    end
end

control "5.5.1.04" do
  title "SELinux mode is targeted"
  describe file("/etc/selinux/config") do
    its("content") { should match "SELINUXTYPE=targeted" }
  end
end

control "5.5.3.01" do
  title "Is SETroubleshoot service removed?"
  describe service("setroubleshoot") do
    it { should_not be_installed }
  end
end

control "5.5.3.02" do
  title "Is MCS Translation Service removed?"
  describe service("mcstrans") do
    it { should_not be_installed }
  end
end

control "5.5.3.03" do
  title "Is restorecond disabled?"
  describe service("restorecond") do
    it { should_not be_enabled }
  end
end
