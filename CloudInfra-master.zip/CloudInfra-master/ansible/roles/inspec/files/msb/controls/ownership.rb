control "5.1.4.2" do
  title "Are the system log files owned by root?"
  describe file_list(%w(/var/log/secure /var/log/messages /var/log/spooler)) do
    its("group") { should eq "root" }
  end
  describe dir_listing("/var/log/audit") do
    its("group") { should eq "root" }
  end
end

control "5.1.4.3" do
  title "Do the system log files have group as root?"
  describe file_list(%w(/var/log/secure /var/log/messages /var/log/spooler)) do
    its("group") { should eq "root" }
  end
  describe dir_listing("/var/log/audit") do
    its("group") { should eq "root" }
  end
end

control "5.2.1.1" do
  title "Are /etc/*cron* and all included files and directories owned by root?"
  describe files_glob("/etc/*cron*") do
    its("owner") { should eq "root" }
    its("group") { should eq "root" }
  end
  describe files_glob("/etc/*cron*/**/*") do
    its("owner") { should eq "root" }
    its("group") { should eq "root" }
  end
  describe file("/etc/crontab") do
    it { should_not be_more_permissive_than '0400' }
  end
end
