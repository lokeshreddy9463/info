control "5.2.1.3.02" do
  title "Do all entries in /etc/exports have secure option?"
  only_if { File.exists?("/etc/exports") }

  describe etc_exports.where { not ["/home", "/opt"].any? {|d| export.start_with? d } } do
    it { should_not exist }
  end
end

control "5.2.1.4.01" do
  title "Does /etc/ssh/ssh_config has protocol 2 underneath host *?"
  only_if { File.exists?("/etc/ssh/ssh_config") }

  describe ssh_config do
    its("Host") { should eq "*"}
    its("Protocol") { should cmp 2 }
  end
end

control "5.2.1.4.02" do
  title "Does /etc/ssh/sshd_config has Protocol=2?"
  only_if { File.exists?("/etc/ssh/sshd_config") }

  describe sshd_config do
    its("Protocol") { should cmp 2 }
  end
end

control "5.2.1.4.03" do
  title "Is /etc/ssh/sshd_config file permission 0600 or stricter?"
  only_if { File.exists?("/etc/ssh/sshd_config") }

  describe file("/etc/ssh/sshd_config") do
    it { should_not be_more_permissive_than "0600" }
  end
end

control "5.2.1.4.05" do
  title "Does /etc/ssh/sshd_config have MaxAuthTries = 5 or Less?"
  only_if { File.exists?("/etc/ssh/sshd_config") }

  describe sshd_config do
    its("MaxAuthTries") { should cmp < 6 }
  end
end

{
  "IgnoreRhosts" => "yes",
  "HostbasedAuthentication" => "no",
  "PermitRootLogin" => "no",
  "PermitEmptyPasswords" => "no",
  "PermitUserEnvironment" => "no"
}.each.with_index do |(k, v), index|
  control "5.2.1.4.0#{6 + index}" do
    title "Does /etc/ssh_sshd_config have #{k}=#{v}?"
    only_if { File.exists?("/etc/ssh/sshd_config") }

    describe sshd_config do
      its(k) { should cmp v }
    end
  end
end

control "5.2.1.4.11" do
  title "Does /etc/ssh/sshd_config have only the approved ciphers in counter mode?"
  only_if { File.exists?("/etc/ssh/sshd_config") }

  describe sshd_config do
    its("Ciphers") { should eq "aes256-ctr,aes192-ctr,aes128-ctr" }
  end
end

control "5.6.1.01" do
  title "Is net.ipv4.ip_forward set to 0?"

  describe kernel_parameter("net.ipv4.ip_forward") do
    its("value") { should eq 0 }
  end
end

control "5.6.1.02" do
  title "Is net.ipv4.conf.all.send_redirects set to 0?"

  describe kernel_parameter("net.ipv4.conf.all.send_redirects") do
    its("value") { should eq 0 }
  end
end

control "5.6.1.03" do
  title "Is net.ipv4.conf.default.send_redirects set to 0?"

  describe kernel_parameter("net.ipv4.conf.default.send_redirects") do
    its("value") { should eq 0 }
  end
end

control "5.6.3.01" do
  title "NTP set to Gilead Time Server"
  
  describe file("/etc/ntp.conf") do
    its("content") { should match /pool \d+\.amazon.pool\.ntp\.org iburst/ }
  end
end

%w(dccp sctp rds tipc).each_with_index do |mod, idx|
  control "5.6.4.0#{idx}" do
    title "Disable #{mod.upcase}"

    describe kernel_module(mod) do
      it { should be_blacklisted }
    end
  end
end

control "5.7.1" do
  title "Is rsyslog running?"

  describe service("rsyslog") do
    it { should be_running }
  end
end

control "5.7.3" do
  title "Audit configuration 1"

  user_commands = ["useradd", "userdel", "usermod", "adduser"]
  user_files = ["passwd", "shadow", "group", "gshadow"]
  system_directories = [
    "/bin", 
    "/sbin", 
    "/usr/bin", 
    "/usr/lib", 
    "/etc", 
    "/boot"
  ]

  describe auditd.syscall("execve").where { fields.any? {|f| f == 'euid=0' } } do
    its("action.uniq") { should eq ["always"] }
    its("list.uniq") { should eq ["exit"] }
  end
  user_commands.each do |cmd|
    describe auditd.file("/usr/sbin/#{cmd}") do
      its("permissions.flatten") { should include "x" }
      its("permissions.flatten") { should include "w" }
    end
  end
  user_files.each do |cmd|
    describe auditd.file("/etc/#{cmd}") do
      its("permissions.flatten") { should include "a" }
      its("permissions.flatten") { should include "w" }
    end
  end
  system_directories.each do |dir|
    describe auditd do
      its("lines") { should include "-w #{dir} -p wa -k sysdir" }
    end
  end
  # This PAM library tracks all login attempts
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /pam_tally2\.so/ }
  end
end

control "5.7.4" do
  title "Audit configuration 2"
  describe package("audit") do
    its("version") { should cmp >= "2.8.0" }
  end
  describe service("auditd") do
    it { should be_running }
  end
end

control "5.7.5" do
  title 'Is "Group" denied write permission to system log files?'

  syslog_files = File.new("/etc/rsyslog.conf").each_line.filter {|l| l =~ /^[^$#]/ }.map {|l| l.split(' ')[-1] }.filter {|f| !f.nil? and File.exists? f }
  syslog_files.each do |path|
    describe.one do
      describe file(path) do
        it { should_not exist }
      end
      describe file(path) do
        it { should_not be_executable }
        it { should_not be_writable.by("group") }
        it { should_not be_writable.by("others")}
      end
    end
  end
end

control "5.7.6" do
  title "Configure rotation of system logs"

  describe file("/etc/cron.daily/logrotate") do
    it { should exist }
  end
end
