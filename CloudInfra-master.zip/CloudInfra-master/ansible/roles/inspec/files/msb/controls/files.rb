control "5.3.3.01" do
  title "Confirm appropriate permissions on passwd, shadow, group, and gshadow files"
  %w(group passwd).each do |f|
    describe file("/etc/#{f}") do
      its("owner") { should cmp "root" }
      its("group") { should cmp "root" }
      it { should_not be_more_permissive_than "0644" }
    end
  end
  %w(gshadow shadow).each do |f|
    describe file("/etc/#{f}") do
      its("owner") { should cmp "root" }
      its("group") { should cmp "root" }
      it { should_not be_more_permissive_than "0400" }
    end
  end
end

control "5.3.4.01" do
  title "Is root's .bash_profile umask 027 or stricter?"
  describe.one do
    %w(.bash_profile .bashrc .cshrc .tshrc).each do |profile_file|
      describe bash_profile_settings("/root/#{profile_file}") do
        its("umask") { should_not be_more_permissive_than "0027" }
      end
    end
  end
end

control "5.4.1" do
  title "Is \"Authorized Users Only\" banner present in /etc/motd?"
  describe file("/etc/motd") do
    its("content") { should match /Unauthorized users of this system may be subject to criminal/ }
  end
end

control "5.4.4.1.03" do
  title "Remove legacy '+' entries from password file"
  describe file("/etc/passwd") do
    its("content") { should_not match /^\+/ }
  end
end

control "5.4.4.2.01" do
  title "Confirm no accounts have empty password hashes"
  describe shadow.where { password.length == 0 } do
    it { should_not exist }
  end
end

control "5.4.4.2.02" do
  title "Confirm all account passwords are shadowed"
  describe passwd.where { password != 'x' } do
    it { should_not exist }
  end
end

control "5.4.4.1.07" do
  title "Are /etc/{bashrc,csh.cshrc,csh.login,profile,skin/bashrc} umask 027 or greater?"
  templates = (%w(
    /etc/bashrc
    /etc/csh.cshrc
    /etc/csh.login
    /etc/profile
    /etc/skel/.bashrc
  )) 
  templates.each do |template|
    describe bash_profile_settings(template) do
      its("umask") { should_not be_more_permissive_than '027' }
    end
  end
end

control "5.4.4.08" do
  title "Are there no users dot-files that are world writable?"
  passwd.homes.each do |home|
    Dir.glob("#{home}/.*").each do |f|
      describe file(f) do
        it { should_not be_writable.by("others") }
      end
    end
  end
end

control "5.4.4.1.09" do
  title "Are there no .netrc files?"
  passwd.homes.each do |home|
    describe file("#{home}/.netrc") do
      it { should_not exist }
    end
  end
end

control "5.4.4.2.04" do
  title "Check /etc/sudoers for %wheel"
  only_if { File.exists?("/etc/sudoers") }
  describe file("/etc/sudoers") do
    its("content") { should match /^%wheel/ }
  end
end

control "5.4.4.2.05" do
  title "Confirm no non-root accounts have UID 0"
  describe passwd.where { user != "root" and uid == 0 } do
    it { should_not exist }
  end
end

control "5.4.4.2.07 and 5.4.4.2.07" do
  title "Check root's path for relative, null or dangerous directories"
  describe env_path do
    it { should_not have_component "." }
    it { should_not have_component_matching "^./" }
  end
  env_path.components.each do |component|
    describe file(component) do
      it { should_not be_writable.by("others") }
      it { should_not be_writable.by("group") }
    end
  end
end

control "5.4.5.3" do
  title "Cron user restrictions"
  describe file("/etc/cron.d/cron.allow") do
    it { should exist }
    its("content") { should_not be_blank }
  end
  describe.one do
    describe file("/etc/cron.d/cron.dent") do
      it { should_not exist }
    end
    describe file("/etc/cron.d/cron.dent") do
      its("content") { should_not be_blank }
    end
  end
end
