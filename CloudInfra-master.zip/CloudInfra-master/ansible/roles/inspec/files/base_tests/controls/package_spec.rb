deprecated_packages = [
  ['inetd', 'xinetd'],
  ['anacron'],
  ['apmd'],
  ['autofs'],
  ['avahi-daemon'],
  ['bluetooth'],
  ['cups'],
  ['ftp'],
  ['gpm'],
  ['pcscd'],
  ['hplip'],
  ['isdn'],
  ['kdump'],
  ['kudzu'],
  ['mcstrans'],
  ['mdmonitor'],
  ['netfs'],
  ['portmap'],
  ['readhead_early'],
  ['readhead_later'],
  ['rpcgssd'],
  ['rpcidmapd'],
  ['setroubleshoot'],
  ['xfs'],
  ['talk'],
  ['rcp'],
  ['rlogin'],
]

deprecated_packages.each_with_index do |packages, idx|
  prefixed_package_num = idx.succ.to_s.rjust(2, '0')
  unless packages.empty?
    control "deprecated-package-#{prefixed_package_num}" do
      title "Do not run deprecated #{packages.join(' or ')}"
      desc 'http://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf, Chapter 3.2.1'
      packages.each do |package|
        describe package(package) do
          it { should_not be_installed }
        end
      end
    end
  end
end

control 'package-29' do
  title 'Do not install Telnet server'
  desc 'Telnet protocol uses unencrypted communication, that means the password and other sensitive data are unencrypted. http://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf, Chapter 3.2.2'
  describe package('telnetd') do
    it { should_not be_installed }
  end
end

control 'package-30' do
  title 'Do not install rsh server'
  desc 'The r-commands suffers same problem as telnet. http://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf, Chapter 3.2.3'
  describe package('rsh-server') do
    it { should_not be_installed }
  end
end

control 'package-31' do
  title 'Do not install ypserv server (NIS)'
  desc 'Network Information Service (NIS) has some security design weaknesses like inadequate protection of important authentication information. http://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf, Chapter 3.2.4'
  describe package('ypserv') do
    it { should_not be_installed }
  end
end

control 'package-32' do
  title 'Do not install tftp server'
  desc 'tftp-server provides little security http://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf, Chapter 3.2.5'
  describe package('tftp-server') do
    it { should_not be_installed }
  end
end

control 'package-34' do
  title 'auditd is present and configured correctly'
  desc 'auditd provides extended logging capabilities on recent distributions'
  describe package('audit') do
    it { should be_installed }
  end
  describe auditd_conf do
    its('log_file') { should cmp '/var/log/audit/audit.log' }
    its('log_format') { should cmp 'raw' }
    its('flush') { should match(/^incremental|INCREMENTAL|incremental_async|INCREMENTAL_ASYNC$/) }
    its('max_log_file_action') { should cmp 'ROTATE' }
    its('space_left') { should cmp 75 }
    its('action_mail_acct') { should cmp 'root' }
    its('space_left_action') { should cmp 'SYSLOG' }
    its('admin_space_left') { should cmp 50 }
    its('admin_space_left_action') { should cmp 'SUSPEND' }
    its('disk_full_action') { should cmp 'SUSPEND' }
    its('disk_error_action') { should cmp 'SUSPEND' }
  end
end

control 'package-35' do
  title 'CIS: Additional process hardening'
  desc '1.5.4 Ensure prelink is disabled'
  describe package('prelink') do
    it { should_not be_installed }
  end
end

control 'package-36' do
  title 'Ensure microcode_ctl is updated version'
  desc 'Older versions of microcode_ctl are deprecated'
  describe.one do
    describe package('microcode_ctl') do
      it { should_not be_installed }
    end
    describe package('microcode_ctl') do
      its('version') { should cmp >= '2.1-47.amzn2.0.4'}
    end
  end
end
