MB = 1024
GB = 1024 * MB

control 'os-01' do
  title 'Trusted hosts login'
  desc "hosts.equiv file is a weak implemenation of authentication. Disabling the hosts.equiv support helps to prevent users from subverting the system's normal access control mechanisms of the system."
  describe file('/etc/hosts.equiv') do
    it { should_not exist }
  end
end

control 'os-02' do
  title 'Check owner and permissions for /etc/shadow'
  desc 'Check periodically the owner and permissions for /etc/shadow'
  describe file('/etc/shadow') do
    it { should exist }
    it { should be_file }
    it { should_not be_executable }
    it { should_not be_readable.by('other') }
    it { should_not be_writable.by('owner') }
  end
end

control 'os-03' do
  title 'Check owner and permissions for /etc/passwd'
  desc 'Check periodically the owner and permissions for /etc/passwd'
  describe file('/etc/passwd') do
    it { should exist }
    it { should be_file }
    it { should be_owned_by 'root' }
    its('group') { should eq 'root' }
    it { should_not be_executable }
    it { should be_writable.by('owner') }
    it { should_not be_writable.by('group') }
    it { should_not be_writable.by('other') }
    it { should be_readable.by('owner') }
    it { should be_readable.by('group') }
    it { should be_readable.by('other') }
  end
end

control 'os-04' do
  title 'Dot in PATH variable'
  desc 'Do not include the current working directory in PATH variable. This makes it easier for an attacker to gain extensive rigths by executing a Trojan program'
  describe os_env('PATH') do
    its('split') { should_not include('') }
    its('split') { should_not include('.') }
  end
end

control 'os-05' do
  title 'Check login.defs'
  desc 'Check owner and permissions for login.defs. Also check the configured PATH variable and umask in login.defs'
  describe file('/etc/login.defs') do
    it { should exist }
    it { should be_file }
    it { should be_owned_by 'root' }
    its('group') { should eq 'root' }
    it { should_not be_executable }
    it { should be_readable.by('owner') }
    it { should be_readable.by('group') }
    it { should be_readable.by('other') }
    it { should_not be_writable }
  end
  describe login_defs do
    its('UMASK') { should include('027') }
    its('PASS_MAX_DAYS') { should eq '180' }
    its('PASS_MIN_DAYS') { should eq '7' }
    its('PASS_WARN_AGE') { should eq '14' }
    its('UID_MIN') { should eq '1000' }
    its('GID_MIN') { should eq '1000' }
    its('SYS_UID_MIN') { should eq '201' }
    its('SYS_UID_MAX') { should eq '999' }
    its('SYS_GID_MIN') { should eq '201' }
    its('SYS_GID_MAX') { should eq '999' }
  end
end

control 'os-05b' do
  title 'Check login.defs - RedHat specific'
  desc 'Check owner and permissions for login.defs. Also check the configured PATH variable and umask in login.defs'
  describe file('/etc/login.defs') do
  end
  describe login_defs do
  end
  only_if { os.redhat? }
end

control 'os-06' do
  title 'Unique uid and gid'
  desc 'Check for unique uids gids'
  describe passwd do
    its('uids') { should_not contain_duplicates }
  end
  describe etc_group do
    its('gids') { should_not contain_duplicates }
  end
end

control 'os-08' do
  title 'Check for .rhosts and .netrc file'
  desc 'Find .rhosts and .netrc files - CIS Benchmark 9.2.9-10'
  output = command('find / -maxdepth 3 \( -iname .rhosts -o -iname .netrc \) -print 2>/dev/null | grep -v \'^find:\'')
  out = output.stdout.split(/\r?\n/)
  describe out do
    it { should be_empty }
  end
end

control 'os-10' do
  title 'CIS: Disable unused filesystems'
  desc '1.1.1 Ensure mounting of cramfs, freevxfs, jffs2, hfs, hfsplus, squashfs, udf, FAT'
  disabled_modules = %w(
      cramfs
      freevxfs
      jffs2
      hfs
      hfsplus
      squashfs
      vfat
      udf
  )
  disabled_modules.each do |mod_name|
    describe kernel_module(mod_name) do
      it { should be_disabled }
    end
  end
end

control 'os-11' do
  title 'Protect log-directory'
  desc 'The log-directory /var/log should belong to root'
  describe file('/var/log') do
    it { should be_directory }
    its(:group) { should eq 'root' }
  end
end

control "required_mounts" do
  title "Required mounts are configured"
  desc "Ensure required mounts exist and have enough space (per STD-00127)"

  expected_mounts = {
    "/" => 20 * GB,
    "/boot" => 900 * MB,
    "/var" => 10 * GB,
    "/opt" => 10 * GB,
    "/home" => 10 * GB,
    "/tmp" => 10 * GB,
  }

  expected_mounts.each do |mountpoint, size|
    describe mount(mountpoint) do
      it { should be_mounted }
    end
    describe filesystem(mountpoint) do
      its("size_kb") { should be >= size }
    end
  end
end
