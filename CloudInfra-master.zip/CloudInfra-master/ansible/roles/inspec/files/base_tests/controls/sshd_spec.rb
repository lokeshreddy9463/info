def ssh_control(name, &block)
  # A convenience method to create a control that only applies for machines with sshd
  control name do
    only_if "sshd is installed" do
      systemd_service("sshd").enabled?
    end

    instance_eval &block
  end
end


ssh_control 'sshd-01' do
  title 'Server: Check sshd_config owner, group and permissions.'
  desc 'The sshd_config should owned by root, only be writable/readable by owner and not be executable.'

  describe file('/etc/ssh/sshd_config') do
    it { should exist }
    it { should be_file }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    it { should_not be_executable }
    it { should be_readable.by('owner') }
    it { should_not be_readable.by('group') }
    it { should_not be_readable.by('other') }
    it { should be_writable.by('owner') }
    it { should_not be_writable.by('group') }
    it { should_not be_writable.by('other') }
  end
end
  
ssh_control 'sshd-02' do
  title 'Server: Do not permit root-based login or do not allow password and keyboard-interactive authentication'
  desc 'Reduce the potential risk to gain full privileges access of the system because of weak password and keyboard-interactive authentication, do not allow logging in as the root user or with password authentication.'
  describe sshd_config do
    its('PermitRootLogin') { should match(/no|without-password|prohibit-password/) }
  end
end
  
ssh_control 'sshd-03' do
  title 'Server: Specify the listen ssh Port'
  desc 'Always specify which port the SSH server should listen to. Prevent unexpected settings.'
  describe sshd_config do
    its('Port') { should eq('22') }
  end
end
  
ssh_control 'sshd-06' do
  title 'Server: Specify protocol version 2'
  desc "Only SSH protocol version 2 connections should be permitted. Version 1 of the protocol contains security vulnerabilities. Don't use legacy insecure SSHv1 connections anymore."
  describe sshd_config do
    its('Protocol') { should eq('2') }
  end
end
  
ssh_control 'sshd-07' do
  title 'Server: Enable StrictModes'
  desc 'Prevent the use of insecure home directory and key file permissions.'
  describe sshd_config do
    its('StrictModes') { should eq('yes') }
  end
end
  
ssh_control 'sshd-08' do
  title 'Server: Specify SyslogFacility to AUTH'
  desc 'Logging should be set to go to the /var/log/auth.log facility by using the SysLog AUTH parameter. This will ensure that any problems around invalid logins or the like are forwarded to a central security file for auditing purposes'
  describe sshd_config do
    its('SyslogFacility') { should eq('AUTHPRIV') }
  end
end
  
ssh_control 'sshd-09' do
  title 'Server: Specify LoginGraceTime'
  desc 'The LoginGraceTime gives the user 30 seconds to accomplish a login. This could be used to conduct a Denial of Service (DoS) against a running SSH daemon.'
  describe sshd_config do
    its('LoginGraceTime') { should eq('30s') }
  end
end
  
ssh_control 'sshd-10' do
  title 'Server: Specify Limit for maximum authentication retries'
  desc 'MaxAuthTries limits the user to three wrong attempts before the login attempt is denied. This avoid resource starvation attacks.'
  describe sshd_config do
    its('MaxAuthTries') { should eq('5') }
  end
end
  
ssh_control 'sshd-11' do
  title 'Server: Enable PubkeyAuthentication'
  desc 'Prefer public key authentication mechanisms, because other methods are weaker (e.g. passwords).'
  describe sshd_config do
    its('PubkeyAuthentication') { should eq('yes') }
  end
end
  
ssh_control 'sshd-12' do
  title 'Server: Disable IgnoreRhosts'
  desc 'Ignore legacy .rhosts configuration, because rhosts are a weak way to authenticate systems and provide attacker more ways to enter the system.'
  describe sshd_config do
    its('IgnoreRhosts') { should eq('yes') }
  end
end
  
ssh_control 'sshd-13' do
  title 'Server: Disable HostbasedAuthentication'
  desc 'This option is a weak way for authentication and provide attacker more ways to enter the system.'
  describe sshd_config do
    its('HostbasedAuthentication') { should eq('no') }
  end
end

ssh_control 'sshd-14' do
  title 'Server: Disable password-based authentication'
  desc 'Avoid password-based authentications.'
  describe sshd_config do
    its('PasswordAuthentication') { should eq('yes') }
  end
end
  
ssh_control 'sshd-15' do
  title 'Server: Disable PermitEmptyPasswords'
  desc 'Accounts should be protected and users should be accountable. For this reason the usage of empty passwords should never be allowed.'
  describe sshd_config do
    its('PermitEmptyPasswords') { should eq('no') }
  end
end
  
ssh_control 'sshd-16' do
  title 'Server: Disable ChallengeResponseAuthentication'
  desc 'Avoid challenge-response and password-based authentications.'
  describe sshd_config do
    its('ChallengeResponseAuthentication') { should eq('no') }
  end
end
  
ssh_control 'sshd-17' do
  title 'Server: Disable GSSAPIAuthentication'
  desc 'If you do not use GSSAPI authentication then disable it.'
  describe sshd_config do
    its('GSSAPIAuthentication') { should eq('yes') }
  end
end
 
ssh_control 'sshd-18' do
  title 'Server: Enable GSSAPICleanupCredentials'
  desc "Automatically destroy the user's credentials cache on logout."
  describe sshd_config do
    its('GSSAPICleanupCredentials') { should eq('yes') }
  end
end
  
ssh_control 'sshd-19' do
  title 'Server: Disable TCPKeepAlive'
  desc 'Avoid the TCPKeepAlive messages to see if the client is still alive, because they are sent over unencrypted connection and are spoofable.'
  describe sshd_config do
    its('TCPKeepAlive') { should eq('yes') }
  end
end
  
ssh_control 'sshd-20' do
  title 'Server: Set a client alive interval'
  desc 'ClientAlive messages are sent over encrypted connection and are not spoofable.'
  describe sshd_config do
    its('ClientAliveInterval') { should eq('300') }
  end
end
  
ssh_control 'sshd-22' do
  title 'Server: DebianBanner'
  desc 'Specifies whether to include OS distribution in version information'
  case os[:family]
  when 'debian' then
    describe sshd_config do
      its('DebianBanner') { should eq('no') }
    end
  else
    describe sshd_config do
      its('content') { should_not match(/DebianBanner/) }
    end
  end
end