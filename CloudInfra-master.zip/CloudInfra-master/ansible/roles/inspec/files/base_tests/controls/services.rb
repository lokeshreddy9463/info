control "ssm-agent" do
  title "Ensure AWS Systems Manager agent is running"

  describe service("amazon-ssm-agent") do
    it { should be_running }
  end
end
