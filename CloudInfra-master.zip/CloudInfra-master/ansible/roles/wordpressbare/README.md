# Bare Minimum Wordpress Stack
This is a small example of what a bare minimum wordpress role would look like. Do not use this for production! This should only be used for development on the wordpress stacks!

For an example on how this ansible role was used, refer to this PR here: [#813](https://github.com/ServiceTransition/CloudInfra/pull/813)

## Usage
Everything here works out of the box, aside from one small nuance with the zips that are provided.
- If using the `env` tag option to specify which zip/sql dunp to use, make sure that in S3, those objects are tagged with `env = environmentName`