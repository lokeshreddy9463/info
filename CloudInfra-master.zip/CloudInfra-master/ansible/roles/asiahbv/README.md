# Gilead AsiaHBV LiverGrant Ansible Role

This role will cover specific details that will be going into the asiahbv livergrant wordpress deployment.

As of now, this role will deploy a bare instance of a wordpress deployment with no additional configuration.

No additional variables or steps are defined in this role; a majority of the work done here is performed by the inherited `wordpress` role.

When the site gets more concrete details, these following items will be replaced.
