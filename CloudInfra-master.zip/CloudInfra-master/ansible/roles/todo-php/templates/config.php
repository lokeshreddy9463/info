<?php
  $host       = "{{lookup('file', '/etc/rds-info') }}";
  $username   = "mvp";
  $password   = "{{ db_password }}";
  $dsn        = "mysql:host={{lookup('file', '/etc/rds-info') }};dbname=tasks";
  $options    = array(
                  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                );
?>
