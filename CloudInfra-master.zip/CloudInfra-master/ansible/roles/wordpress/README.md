# Wordpress
Wordpress Version support range: (5.2.2 - 5.2.7)

This documentation serves to go over the wordpress deployment role for Ansible. There are __two ways__ to go about a Wordpress installation, one of which requires some extra pre-requesites.

## Pre-Reqs
1. zip file containing the wordpress installation/contents (__Required__ for existing Wordpress Installation)
    > When a zipping a file or retrieving a zip file to feed into the ansible role, make sure that the zip file contains only the wordpress related files, and not nested under a top level directory. What this means is that do not zip a directory. You want to zip files so that when you unzip the zip file, you don't get the top level directory. Here's the command that you would want to run:

    ```
    cd <directory_where_all_your_wordpress_files_live>
    zip -r <zip_filename>.zip *
    ```

2. sql dump of the database containing the wordpress installation. Currently only supports MySQL. (__Required__ for existing Wordpress Installation)
    > The sql dump file should have sql commands that drop the database if the database already exists wherever it is migrating to.

    > This dump can also be created by oneself by performing the following commands. This is described in details in this [article](https://www.maxmanders.co.uk/2014/03/25/restoring-a-mysql-dump-to-rds.html).
    ```
    # This is presuming the instance running this has access to an RDS instance

    # Grab only the necessary databases to save
    DATABASE_LIST=$(mysql -NBe 'show schemas' -h <database URL> -u <username> -p | egrep -v "informati
    on_schema|innodb|mysql|performance_schema" | tr "\n" " ");

    # Perform a sql dump on the server
    mysqldump -h <database URL> -u <username> --skip-lock-tables --databases ${DATABASE_LIST} --add-drop-database --triggers --routines --events --set-gtid-purged=OFF -p > dump.sql
    ```

3. List of php modules required by wordpress

4. Any configuration updates to httpd/apache conf file

## Bare Minimum Installation
If a user wants to perform a basic wordpress installation for MVP/testing purposes (do NOT use this for production), follow the following:

1. Create a new Ansible role in `ansible/roles`, and define the following:
    * `roleName/var/main.yml`:
        ```
        wp_version: 5.2.2
        wp_dbname: `<projectName>`
        wp_title: "<TitleToUse>"

        # These variables will change depending on your stack; refer to step 3 for specific details
        cloudfront_setup: false
        alb_setup: true
        https_enabled: false
        ```
    * `roleName/meta/main.yml`
        ```
        ---
        dependencies:
        - role: wordpress
        ```
2. Create a new playbook titled `playbook-<projectName>.yml` that calls on this role, placing it in the `ansible` folder.
    * Example:
        ```
        ---
        - name: Project Name
            hosts: localhost
            become: true
            roles:
                - {role: 'fluentbit', tags: 'wordpress'}
                - {role: '<createdRole>', tags: 'wordpress'}
            tasks:
                - import_role:
                    name: cron
                tags:
                    - always

        ```
3. Create a deployment stack in your given account.
    - An example of this can be seen in the `env/dev/shared-services/ap-southeast-2` deployment of the `hivaustrailia` wordpress module.
    > `<projectName>` __MUST__ match the `project` parameter that will be passed into the `wordpress` module.
    > Depending if the wordpress stack is using Cloudfront, ALB and/or HTTPS, configure the necessary variables in the ansible roles as well (which is shown in the example)

## Existing Wordpress Deployment
If a user is wanting to leverage this ansible role to migrate an existing wordpress installation, there are
some additional requirements to be aware of:

1. Make sure to obtain both the wordpress zip and sql dump that will be leveraged from that site.
    - Either the `version_id` or an `env` object tag value can be leveraged in the role.  
2. Make sure to configure any necessary extras to the deployment (php parameters, plugins) in the ansible role that will be leveraging this base role.
3. Make sure to check what requirements are needed in the deployment and make sure that all of the needed parameters that can be specified in the role vars are satisfied in your inherited ansible role.

An example of what this looks like can be seen in the `hivaustraila` ansible role.

## Troubleshooting
> I cannot log into `wp-login.php`! The site is saying something is wrong!

If you see this error, it is most likely the CloudFront caching that is causing this issue. Essentially, if changes are made onto the Wordpress server after CloudFront was configured to serve the website, CloudFront will __not__ pick up those changes.

To resolve this:
1. Navigate to the terraform deployment root where the wordpress site is being spun up.
2. Tain the terraform resource that is spinning out the `CloudFront` resource
3. `terraform apply`
4. Navigate onto the wordpress instance and run the following commands:
```
$ sudo su
$ cd /var/www/wordpress/
$ wp-cli search-replace $(wp-cli option get siteurl) newCloudFrontURL
$ systemctl restart httpd
```

These commands will point the wordpress site to be using the new CloudFront instance. After performing these steps, you should now be able to access wordpress again and access `wp-login` as well.

> Too many redirects

If you see a **Too many redirects** error when accessing wp-admin, adding the lines below to `/var/www/wordpress/wp-config.php` and restart `httpd`.

```
define('FORCE_SSL_ADMIN', true);

if (strpos($_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false)
$_SERVER['HTTPS']='on';
```
