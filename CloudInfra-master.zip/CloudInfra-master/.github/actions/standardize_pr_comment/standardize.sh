#!/bin/bash

set -e

vars=(
  url
  comments_url
  repository_url
  comment
  number
)

script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
escape_output_cmd="${script_dir}/../../../scripts/action-output.sh"

if [ "${event_type}" = "issue_comment" ]; then
  event_prefix="ic"
  echo "Event is issue comment"
elif [ "${event_type}" = "pull_request_review_comment" ]; then
  event_prefix="prrc"
  echo "Event is review comment"
else
  echo "::error::This action can only be run on issue_comment or pull_request_review_comment events"
  exit 1
fi

for suffix in "${vars[@]}"; do
  var_name="${event_prefix}_${suffix}"
  output="$(${escape_output_cmd} <<< ${!var_name})"
  echo "Setting ${suffix} to '${output}'"
  echo "::set-output name=${suffix}::${output}"
done
