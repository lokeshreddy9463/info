# GitHub Actions Workflow Templates
This document will cover the workflows that exist in this folder as well as the purpose of the existance of this directory.

## Table of Contents
- [Overview](#Overview)
- [How to Install](#How-to-Install)
- [zip-publish-artifact-s3](#Zip-Publish-Artifact-S3)
- [promote-s3-zip](#Promote-S3-Zip)

## Overview
All `yml` present in this directory are created to run out of the box with little to no pre-requirements. Due to a limitation on GitHub's ability to [share workflows in an organization](https://github.community/t/github-repo-workflow-templates-only-public/126583), all users who wish to leverage these workflows must have read permission on this repository.

## How to Install

### Automatic
> This method only works if the repository that will be leveraging these has not been made yet.

> This leverages a GitHub Repository Template. Said template needs to have any corresponding workflows set up in that repository first. To add the workflows in a template repository, the manual process needs to be done.

1. In the `env/prod/github/servicetransition` root, call on the `github_repo` module, specifying the `template_config` parameter (more information can be found [here](../../modules/git_repo/README.md)), mentioning the template repo of choice.
2. Perform our standard [terraform workflow](../../docs/terraform/terraform-development.md) to get the new repository created, which will inherit the workflows that are in the template repository.

> If the template repository gets an update on the workflows, all repositories will not automatically get this change; they will need to perform the manual step to get any new changes once the repo has been made.

### Manual
1. Copy the yml file of interest into your repository under the directory, `.github/workflows/` (create it if it does not exist)
2. Modify the top level `envs` to match your deployment.
3. Open a new PR to add these into the repository
4. Done. They should now appear in the `Actions` tab (if formatted correctly)

> If there is an error in the `yml`, the `Actions` tab will point out the errors accordingly.

## Zip-Publish-Artifact-S3
This workflow automates the ability of a repository to automatically zip up its contents and send it to a S3 bucket, tagging it with `env=dev` and optionally, `ss_bucket=XXX` and `repository_name=XXX`. The end result is a S3 object version. There are two ways to invoke this workflow:
1. **Manually**: Anyone who can view the `Actions` tab of a repository can invoke this run anytime in the repository.
2. **Chat Ops via PR**: In a new PR, anyone can fire off a CI job to automatically zip up their current PR branch up to S3.

When a new zip is published to S3 by either workflow, any previous zip version that was tagged `env=dev` will be removed and added onto the new zip that gets added.

## Pre-Reqs
- AWS Credentials that have access to the S3 bucket that will be holding the zips (stored as a GitHub Action secret, named the same as the standard AWS CLI env variables)
- Replace the values for the top level `envs` :
```
env:
  DES_S3: "gilead-aws-devops-artifacts-us-west-2"
  ACC_NAME: "your-aws-account-name" (i.e. mvp, shared-services)
  DEV_SS_S3: "your-dev-static-site-bucket-name" (leave blank if product is not a static site)
```

### Manual
This can be invoked by going to the `Actions` tab, selecting this workflow and selecting `Run workflow`.

All logs and results can be viewed in the resulting workflow run that gets created.

### Chat Ops
In an open PR, any person can invoke the CI job by commenting the following:
```
publish
```

The CI will by default (which can be edited in the `yml`) will output a result comment from the `github-bot` user. This comment will give insight on whether the build was successful or failed.

## Promote-S3-Zip
This workflow works in tangent with the **Zip-Publish-Artifact-S3** by promoting tagged zips in the specified S3 bucket to the next environment. The path of promotion is tied to a specific invokation style:
- `dev` -> `tst`: Performed by pushing a tag to the repository
- `tst` -> `prd`: Performed by invoking this workflow manually

The end result is a S3 object version ID that is tagged approperiatly.

### Pre-Reqs
- AWS Credentials that have access to the S3 bucket that will be holding the zips (stored as a GitHub Action secret, named the same as the standard AWS CLI env variables)
- Replace the values for the top level `envs` :
```
env:
  DES_S3: "gilead-aws-devops-artifacts-us-west-2"
  ACC_NAME: "your-aws-account-name" (i.e. mvp, shared-services)
  TST_SS_S3: "your-tst-static-site-bucket-name" (leave blank if product is not a static site)
  PRD_SS_S3: "your-prd-static-site-bucket-name" (leave blank if product is not a static site)
```

These values _must_ reflect the same values used in the **Zip-Publish-Artifact-S3** workflow.

All results of this workflow can be seen in the Actions tab of this specified workflow.

### dev to tst
This promotion is the most flexible out of the two in that as long as a new tag is pushed up, the resulting zip will be tagged with `env=tst` and optionally `ss_bucket=XXX` and `repository_name=XXX`. If another tag is pushed up after the initial tag, the new zip will **take** the `env=tst` tag, removing the previous tags on the older zip.

This promotion process _must_ take place before performing a promotion to `prd`.

### tst to prd
This promotion is the more strict one out of the two; requiring an existing zip to contain the `env=tst` tag. To perform this promotion, a manual run must be initialted from the Actions page.

By default, the runner must confirm the run to occur. Once activated, the job will find an object version that is tagged `env=tst`, download it locally and reupload it with the `env=prd` tag.

> The reason for this reupload is to allow for the S3 bucket to fire off an Event Notification to a Lambda function.
