# CloudInfra Releases

> There is a mirror of this document in [Confluence](https://gileaddevops.atlassian.net/l/c/qu7jZyvJ). This document here has the most up to date information.

Releases are done in two steps, `tst` and then `prd`. `val` roots are released with `tst`.
The release process for accounts/environments depends on their location within the repository.
  1. 1-N roots (roots located within the [terraform/account_specific](https://github.com/ServiceTransition/CloudInfra/tree/master/terraform/account_specific) directory) are released to tst when an `RC/x.y` (e.g. `RC/1.42`) branch is pushed to Github, and then released to prd when an `x.y.z` (e.g. `1.42.0`) version tag is pushed to Github. 
     The additional number on the release allows for hotfixes within a given release, which are first cherry-picked into the RC branch, and then a new tag (e.g. `1.42.1`) is created and pushed. The RC branch is never merged to master because it should never contain any new changes.
     It's just a trigger. All 1-N roots are "promoted" (updated) during every release (unless specifically held back). 
  2. Legacy [env/](https://github.com/ServiceTransition/CloudInfra/tree/master/env) roots are "promoted" by updating references to the modules they instantiate so they point to the RC/x.y branches and tags created during the 1-N release. These changes are made on feature branches and applied by Atlantis in pull requests. 
     newer `1 - N` workflow and our legacy workflow. Resources defined directly in legacy `env/` roots (outside of modules) aren't pinned to versions. They release at whatever version of code is in the pull request when Atlantis runs.
     That version may be different from the one pinned in the root's modules. This difference is one of the reasons to migrate to the 1-N pattern, where all code in a root is released at the same version.
  
## Steps

These steps are written as an example of release ticket `DEV-1234` done by a user with the initials `jd`. There will be two sections, one for releasing changes to `1 - N` roots and another for legacy `env` roots. They release `RC/0.5` ("release candidate 0.5") to `tst` and version `0.5.0` to `prd`. They assume familiarity with the CloudInfra automation. See the [docs](docs/) for more information.

### Workflow Common Steps

Release information and proposed changes (terraform/atlantis plans) for both `1 - N` roots and legacy `env/` roots are included in the same Pull Request (PR) and within the same Change Request (CR) (if the release is to PRD).

1. Create the branch `jd/DEV-1234-tst` or ( `jd/DEV-1234`) from the tip of `master`.
1. Create branches and tags for the release:
   * For `tst`: Create and push branch `RC/0.5` from the tip of `master`.
   * For `prd`: Tag the tip of the `RC/0.5` branch as `0.5.0` and push the new tag. Increment this version whenever you apply a [hotfix](#hotfixes).
1. Open a pull request from `jd/DEV-1234-[tst|prd]` to `master`. Refer to the PR description mentioned in the [first approval section](#first-approval-pass).
1. [Generate release notes](#generating-release-notes).
1. `prd` only: [Create a CR](#creating-a-change-request).
    >NOTE: This step should be performed after PRD plans have been generated for both legacy and 1 - N roots.
1. Add the CR number `CHG-########` to the PR description.
1. Perform all steps outlined in the `1 - N` and `Legacy Env Roots` sections below.
1. Merge the pull request from `jd/DEV-1234-[tst|prd]`to `master` (This step should be performed after all steps for 1 - N and legacy roots below have been completed).

### 1 - N Roots

1. The Multi TF Invoker GitHub Actions Workflow is automatically triggered by the push of branch `RC/0.5` (tst) and tag `0.5.0` (prd). These workflows [promote by default](#promoting-all-code-by-default) and don't need module reference updates.
1. "Approve" the **plan** step of the Multi TF Invoker's run to start terraform plans of 1-N (v2) roots.
1. Add a link to the Multi TF Invoker's run to the PR description mentioned in the `Workflow Common Steps` section above.
1. `prd` only: Ensure that your CR has been approved. Change CR status to implement.
1. Have a peer approve the **apply** step of the Multi TF Invoker run to start terraform applies of the 1-N roots.
1. Verify that applies have completed successfully and perform necessary validation. If errors are encountered, perform a hotfix and go through steps 1 - 3 and 5 again.
   > NOTE : If issues encountered can not be solved within your CR window. Create a new CR to fix the issue.

### Legacy Env Roots
1. "[Promote](#promoting-roots)" (increment) terraform module references on `jd/DEV-1234-[tst|prd]`.
   * For `tst`: point modules to the new `RC/0.5` branch.
   * For `prd`: point modules to the new `0.5.0` (or hotfix version).
   * Check for module references that were held back at older versions that may need to be specifically promoted. See warning in the [promotion section](#promoting-roots).
   * Push changes to remote branch.
   1. `atlantis plan` on the pull request to start terraform plans of the legacy `env/` roots.
   1. Review the Atlantis plans.
      * ⚠️ Check for changes to `env/prod/devops/us-west-2` that will rotate the Atlantis container. This root deploys the Atlantis that deploys this root. If the container will rotate, that change should be applied **locally** and should follow the steps to [update without killing applies](docs/atlantis/atlantis-config-deployment.md#updating-without-killing-applies). If you apply it with Atlantis, the apply will kill the container that's doing the apply. Consequences of this are hard to predict.
      * Watch out for changes to `env/` roots that aren't in `module.[module name]` paths in the terraform diffs. The only changes in the ticket branch should be references to module versions, so changes in non-module resource paths are unexpected and may indicate manual changes in accounts or other problems that need investigation.
      * Typically, the diffs for `env/` roots will be minimal. Those roots are [applied to all environments in pull requests](docs/terraform/terraform-development.md). By the time releases start, most work will already have been applied.
   1. Cherry-pick any [hotfixes](#hotfixes).
   1. Start and review new plans `env/`. Loop on plans and hotfixes until plans pass review.
1. `prd` only: Wait for CR approval.
1. `atlantis apply` on the pull request to start terraform applies of the legacy `env/` roots.

### Hotfixes
A "hotfix" is a change added to a release after its `RC/` branch has been created.

1. Test the change in `dev` and have it merged into `master` in a PR, as usual.
1. [Cherry-pick](https://git-scm.com/docs/git-cherry-pick) the change from `master` into the `RC/` branch.
1. Deploy in `tst` using the steps above.
1. Bump the version number, create a new tag, and deploy to `prd` using the steps above.

### Promoting Roots
**⚠️ Warning**: This will only update module references that are specifically set to `OLD_VERSION`. If a module is set to any other version, it won't be updated. For example, suppose a module on version 0.4.0 is held back during the 0.5.0 release because of compatibility problems. On the next release (from 0.5.0 to 0.6.0), searching for the 0.5.0 pattern will *miss* the module that was held back at 0.4.0. Unless you specifically check for these cases, references can become orphaned. It's a good idea to search for any references older than the current RC and version and review any you find.

```
cd env
OLD_VERSION=[current RC branch version or tag] NEW_VERSION=[new RC branch version or tag] make [tst|prd]
```

To promote to the `RC/0.5` release in `tst` when the current `tst` release is `RC/0.4`:

```
OLD_VERSION="0.4" NEW_VERSION="0.5" make tst
```

To promote to the `0.5.0` `prd` release when the current `prd` release is `0.4.0`:

```
OLD_VERSION="0.4.0" NEW_VERSION="0.5.0" make prd
```

## Promotion Types

In order to understand how the release process works, one needs to understand the difference kinds of **promotion types**. There's a notable difference in promotion styles in different roots:
- Promotion in `env/` roots
    - Promoting **`modules/`** **`awslambda/`** and **`ansible/`** references
        - These resources are centralized in a given module that has its *source version* defined in code.
        - Examples:
            - dev/opsdev:
                - [module](./env/dev/shared-services/us-west-2/module.tf#L2)
                - [ansible](./env/dev/shared-services/us-west-2/module.tf#L92)
            - tst
                - [module](./env/tst/shared-services/us-west-2/module.tf#L2)
                - [ansible](./env/tst/shared-services/us-west-2/module.tf#L92)
            - prd/val
                - [module](./env/prod/shared-services/us-west-2/module.tf#L2)
                - [ansible](./env/prod/shared-services/us-west-2/module.tf#L114)
            - awslambdas
                - [Part 1](./modules/acct_reset_email_filter/data.tf#L3) and [Part 2](./modules/acct_reset_email_filter/acct_reset_email_filter.tf#L4)
    - Promoting resources **external from terraform/lambda/ansible modules**.
        - These resources are *independent* of a module and are generally one-off in a given deployment.
        - Utilizes the `master` branch or branches originating from `master` for their deployment
        - Examples:
            - [dev/opsdev](./env/dev/shared-services/us-west-2/key_pair.tf)
            - [tst](./env/tst/shared-services/us-west-2/key_pair.tf)
            - [prd/val](./env/prod/shared-services/us-west-2/key_pair.tf)
- Promotion in `terraform/` roots
    - Promoting **all code**
        - All code, **regardless if in a module or not** will be promoted consistently to each environment, unless otherwise specified in said code.
        - Example
            - Using variable interpolation: [Ex 1](./terraform/account_specific/gilead-kite-kdh/us-west-2/data.tf#L12) and [Ex 2](./terraform/account_specific/gilead-edp-engineering/us-west-2/modules.tf#L3)

> NOTE: The root, `terraform/`, and the phrase, `terraform module`, are **NOT** the same in this repository context. A `terraform module` is a **single** directory that contains terraform code. The root, `terraform/` refers to the repository root directory that contains `terraform modules` that comply with the **1-N Workflow**

### Promoting terraform/lambda/ansible modules (`env` root)

The promotion for these resources are performed **automatically** after every sprint (2 week intervals). Specifically, the only thing to keep in mind for these promotions is:
- Make sure all `tst` and `prd` module sources are pointing to the proper branch/tag respectively.
- \* Make sure that the module that you want to leverage in `tst` and `prd` are declared in the appropriate root.

\* The module deceleration can be done either *during* or *after* the release cycle. Regardless of which option is chosen, the module will be promoted as expected.
- If one desires their promotion *during* a release PR:
    - The original `dev` PR that introduced that module *must* indicate that this module be instantiated to `tst` and `prd`.
    - Describe in the original `dev` PR any necessary steps + additional nuances to ensure the changes are promoted properly.
- If one desires their promotion *after* the release PR is merged:
    - Ensure that they are using the proper `RC` and/or `tag` source that has their module change, which is indicated by checking the [CHANGELOG.md](./CHANGELOG.md)
    - Follow standard procedure for PRs and testing for said environments.

### Promoting external resource from terraform/lambda/ansible modules (`env` root)

The promotion for these resources as of this writing *do not require either using RC or tags nor a release PR*. As long as the functionality of a deployment using those resources are confirmed in `dev`, these can be propagated **anytime**.

A team *could* leverage the release cycle to perform the promotion of these resources, however, the following needs to be conveyed:
- The original `dev` PR that introduced that module *must* indicate that this module be instantiated to `tst` and `prd`.
- Describe in the original `dev` PR any necessary steps + additional nuances to ensure the changes are promoted properly.

### Promoting All Code by Default

Recently, there is a shift in how the promotion process works in CloudInfra; one root will dictate the deployment for multiple environments. These roots are deployed using *atlantis* (for dev) and *GitHub Actions* (tst and prd).

The idea behind these is to make deployments consistent through each transition, meaning that **dev == tst == prd**, with environment specific nuances interpolated at deployment runtime. This grants us the following:
1. Easier promotions to higher envs
2. More predictable changes being rolled out
3. Easier testing to confirm that changes made in dev will be identical to higher envs

This promotion workflow is coined, **1-N Workflow**. More details can be read [here](docs/terraform/terraform-development-v2.md).

### Roll Forward or Backward

Determining if a change from a failed release should be resolved via roll back or roll forward can be tricky. Below is a loose guideline to help with that decision making process.

#### Determining Factors

1. Testing
 - The most important factor in determining if a change is easiest resolved by rolling forward is if there is adequate testing around the change and a strong understanding of what went wrong with testing that resulted in the failed release.
2. Version Dependency Collision
 - If the problem originates from the version of one module causing dependency issues with the first then rolling forward is the best procedure. Fix up the issues with the conflicting module via a **cherry-pick** and bump the version.
3. Necessity
 - In some cases there is a necessity to roll forward such as major changes to versions of tools that have a system state such as the statefile from Terraform or expected feature release that can not be delayed with a roll back.
4. Customer Impact/Risk
 - The significance of impact from downtime/outage. If rolling forward requires a significant amount of development work then it is likely best to just roll back assuming the previous criteria are taken into consideration.

#### Roll Forward

This section will provide instructions on how to roll forward with changes in order to fix up issues in a previous release.

To resolve issues with a previous release make sure your `MASTER` branch is in line with your upstream remote. Fix the changes in a new PR. Once the changes are reviewed and merged a new release should be cut bumping the version so that it can be used for a release.

#### Roll Back

If a promotion process does not go smoothly and a roll forward is not the desired solution then this section will provide best practices for rolling back or demoting your environment.

This process may not work in all scenarios and as **3. Necessity** calls out certain contexts where rolling forward is the only reasonable solution.

For higher environments simply select the previous release candidate - `RC/****` or tag - `0.**.**` and perform a release using that version.

Once the environment has been pointed to a previous release in higher environments resolve the issue in master and include it in the failed release with a **cherry-pick**.

`git revert` is a powerful tool to sidestep the human error in reverting changes from a bad commit.

## Approval Process

With the nature of how releases touch a lot of roots and/or business impacting roots, ensuring that the proper testing and feedback on all releases is crucial to uphold. As such, all of the standards for [approving](../../APPROVING.md) and [contributing](../../CONTRIBUTING.md) apply here along with the following:
- First Approval Pass
    - This is to get an approval to *proceed* with modifying the deployment that is outlined in the PR.
- Second Approval Pass
    - This is to get an approval that the deployment succeeded **and** confirmation that the PR is ready for merge.

### First Approval Pass

For `tst` and `prd` releases, the main practice is to have separate PRs that will be encompassing all of the work that the release will be doing. These PRs should have the following items in them before it is ready for a formal review:

1. A PR description that contains the following:
    - Sprint number and name of RC/tag that was created
    - List of all roots that have been promoted
    - List of roots that are going to be skipped/promoted but not applied, if applicable
    - List of all general changes made in the last sprint
    - List of all changes made to the `tst` environment
    - List of all changes made to the `prd` environment
    - Bug Fixes, if applicable
    - A list of tests to perform that are in the following format:

```
- [] atlantis plan
- [] atlantis apply
- Confirm the following changes:
    - [] Change 1
    - [] Change 2
    - ...
```

> This changelog can be automated by using [this](https://github.com/Nebulaworks/orion/tree/main/scripts/gen_release_notes) script

2. Perform an `atlantis plan` to obtain all changes for the specific environment
3. Confirm that the GitHub Action, **Multi TF Invoker**, was invoked properly for said environment
4. A PR comment to *summarize* the new changes going out.
    - An example of what this looks like can be seen [here](https://github.com/ServiceTransition/CloudInfra/pull/1490#issuecomment-882959732)
5. If a prod release, a change request number is present in the PR description, which can be gotten [here](../../RELEASE.md#creating-a-change-request)

Once all of this information is present in the PR, post a link to this PR in MS Teams to the following channels, announcing that the release for that particular environment is starting soon:
    - `WIO Cloud DevOps -> WIO Cloud support`
    - `WIO Cloud DevOps -> DevOps`

From there, await for a review from one of the individuals to [this](../../RELEASE.md#Required-Reviewers)
) section, which will be considered a **PR Approval**. These reviews confirm the following:
- The PR description makes sense and contains all relevant information
- All plans made by Atlantis and the GitHub Action makes sense
- Any feedback that was addressed earlier have gotten an appropriate conclusion.

### Second Approval Pass

Once the first approval has been granted, the following should be done:
1. Perform `atlantis apply` as described previously
2. Proceed with the **Multi TF Invoker** job by mentioning the approvers name in the `review deployment` button for said job
3. Confirm that all deployments succeeded and all changes went out

Once done, inform the same threads in MS Teams about the release as well as getting approval from the required reviewers again.

The approval that is obtained here is considered a **Merge Approval**. This approval *encompasses* all of the points mentioned for **PR Approval** along with the following:
1. The PR follows *all expectations* for PRs in CloudInfra, which are found [here](../../APPROVING.md) and [here](../../CONTRIBUTING.md)
2. The final comment update is approved and all action items are accounted for
3. The PR author has confirmed *explicitly* in the PR that the PR is ready for merging, which the approver has confirmed.

### Generating Release Notes
During a release, it is **required** that new release notes for that release cycle are created and added from the top up in the [CHANGELOG.md](./CHANGELOG.md). These notes help summarize and capture all activity in the repository during a sprint cycle.

There are a few ways to generate these release notes:
1. Install the python library, `gen_release_notes` from [this](https://github.com/Nebulaworks/orion/tree/main/scripts/gen_release_notes#readme) repository and run it. (*recommended*)
1. Run the script, [gen_release_notes.sh](./scripts/gen_release_notes.sh), following the instructions in the script comments

Nuances:
- Only `tst` and `prd` changes should be captured in the release notes
- During a release, make sure to capture what roots are being skipped and the reason for them being skipped

### Creating a Change Request

All changes to `prod` require a corresponding CR to be created and tracked within SPARC. Since our releases are a bi-weekly event, we want to make an **Informational** change request. These allow us to raise awareness of changes that could be of interest to some individuals.

A summary of this process this can be seen below:
1. Log into [SPARC Service Now Portal](https://sparc.service-now.com/navpage.do)
    - You will need to have additional SPARC permissions to log into this portal
2. On the Navigation Panel, under, `Change`, select **Create New**
3. Select "Normal".
4. Under **Short Description**, fill with: `CloudInfra Release <Current Release Number>`
5. Under **Description**, fill with the following:

```
Please see attachment for release notes for Cloud Infra's Release for sprint <Sprint Number>

Direct Link: <Link to ChangeLog in CloudInfra>
```

6. Attach PDF version of Changelog to CR
7. Under Schedule, fill in the time slots to be the day you are planning to make the CR, and fill in **NO** for `Outage Required`
8. Save and then select `Scheduled`
9. Once the release starts, update the CR to be `Implement`
10. Once the release is over, update the CR to be `Closed`, making sure to close the CR task.

[Documentation Link](https://gvault.veevavault.com/ui/#doc_info/1070993/8/0?idx=0&pt=asl&sm=47034551639591972700&tvsl=JnNlYXJjaD1XUkstMDMxNzgmaXZwPTEmaXZyPTAmaXY9MSZpdm89ZGVzYyZpdnM9JmZjYWM9JmFsbFN0dWRpZXNTaXRlcz0mc209NDcwMzQ1NTE2Mzk1OTE5NzI3MDAmc21hcnQ9dHJ1ZSZpdnY9Q09NUEFDVCZ2aWV3SWQ9YWR2U2VhcmNoJmZhY2V0c1VuY2hhbmdlZD1mYWxzZQ%2C%2C&anQS=page24&annotate=false)

## Required Reviewers

> This list stems from the [CODEOWNERS](./CODEOWNERS) file.

### Release and Promotion PRs

- All Environments
    - Required
            - At **least** one individual from the following:
                - ServiceTransition/Nebulaworks team
            - **The original PR author of a change** that is promoted from a lower environment
    - Optional
        - **Any** individual from the following:
            - Akhila Kancharla (akancharla1)
            - Divya Prasanth (divyaprasanths)
            - Vibe Charon (VibeCharon)
            - Thangaraj Subramani (tsubaramani1)
            - Praveen Parvataneni (pparvataneni)
- Specific Environments
    - `env/tst/security/`
    - `env/prod/master/global`
    - `env/prod/logging/`
    - `env/prod/networking/`
    - `env/prod/security/`
        - Required
            - At **least** one individual from the following groupst :
                - Any Executive Director in charge of cloud operations
                - Engineers from the CPE team.
    - `env/prod/empower/`
        - Required
            - At **least** one individual from the following **if any major** changes are occurring:
                - John LeBouef (johnleboeuf)

## JIRA Workflow

The DevOps team have a separate task board dedicated for keeping track of issue promotion called **[DnD](https://gileaddevops.atlassian.net/secure/RapidBoard.jspa?rapidView=100)** (Done and Done). This board contains 5 swim lanes, ordered in sequential order:
1. Confirmed on Dev
    - All issues that are marked as **Done** in the DevOps Sprint Board are automatically placed in here. These presume that all of the issues that come in here are deployed to `dev` and work in `dev`.
    - \* Only exceptional swimlane if that if there is an issue that is only applied to prod and/or is not related to any infrastructure (documentation, research), those issues can immediately be moved to `Deployed on Prod`.
2. Deployed on Tst
    - Any issue that got promoted either the release process or cherry pick should end up here once the deployment gets deployed in `tst`.
        - Requires the issue to be confirmed in dev to proceed into here.
3. Confirmed on Tst
    - Any issue that was deployed in `tst` are confirmed to work in `tst`.
4. Deployed on Prod
    - Any issue that is promoted and works in `tst` can then be promoted to prod
5. Confirmed on Prod
    - The final step in the release; once an issue is confirmed on prod, the issue is closed out.

## References
- [SWIM Diagrams](https://gileadconnect.sharepoint.com/:b:/t/WIOCloudDevOps/EfnFI97jigpIkgiguQFPksYBavwxVHWw_SSyL9QGXnZ4ow?e=yhjfYM)
    - Refer to the **SWIM - Release Process** diagram on page 4.
- [DnD Board](https://gileaddevops.atlassian.net/secure/RapidBoard.jspa?rapidView=100)
- [Trunk based development deepdive](https://trunkbaseddevelopment.com/)
- [Branch strategy anti-patterns](https://www.thoughtworks.com/insights/blog/enabling-trunk-based-development-deployment-pipelines)
- [From `gitflow` to `trunk`](https://medium.com/safetycultureengineering/trunks-are-not-just-for-trees-from-git-flow-to-trunk-based-development-949d580697ef)
