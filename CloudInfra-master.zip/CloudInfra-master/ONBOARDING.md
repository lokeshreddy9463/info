# Onboarding

> This document serves to onboard new individuals to working at Gilead's WIO Cloud Team. As such, this document serves as the source of truth. A copy of this will be placed in MS Teams.

Welcome to the WIO Cloud DevOps Team! We are excited to have you contributing and assisting Gilead's internal infrastructure. In order for you to be fully onboard the team, there are a few steps that need to be taken.

## Table of Contents

- [Onboarding](#onboarding)
  - [Table of Contents](#table-of-contents)
  - [Points of Contact](#points-of-contact)
  - [Minimum Contributor Expectations](#minimum-contributor-expectations)
  - [Required Trainings](#required-trainings)
  - [Required Access](#required-access)
    - [Gilead Account Access](#gilead-account-access)
    - [Gilead Cloud Provider Access](#gilead-cloud-provider-access)
      - [Logging In](#logging-in)
    - [GitHub Access](#github-access)
    - [Jira Access](#jira-access)
  - [Optional Access](#optional-access)
    - [Gilead Network Access](#gilead-network-access)
      - [Pre-Req](#pre-req)
      - [GADI Access](#gadi-access)
      - [VPN Access](#vpn-access)
    - [Confluence Access](#confluence-access)
    - [Required Tooling](#required-tooling)
      - [Git](#git)
      - [Terraform](#terraform)
      - [AWS CLI](#aws-cli)
      - [New Relic](#new-relic)
  - [Next Steps](#next-steps)
  - [Further Readings](#further-readings)

## Points of Contact

1. Srinivas Subbarao (Reach out on MS Teams)
2. Executive Director in charge of cloud ops (TBD)
3. IT Front Desk
    - +1.844.827.4373 (USA)
    - 91 3877200 (Espana)
    - 555 3500 955 (Mexico)
    - 0800 444 0927 (Argentina)

## Minimum Contributor Expectations

- Demonstrated expertise of at least one (1) other programming languages (Preferably Python or Go)​
- Demonstrated expertise in shell scripting (Bash)​
- Experience with Continuous Integration tools and processes (Github Actions, GitLab CI, Jenkins, Circle, Drone, etc.)​
- 3 years of hands-on experience in each of the following:​
  - Git branching strategies, workflows, and release engineering approaches to software development​
  - Experience building highly automated infrastructure and cloud-native applications deployed in AWS, GCP, or Azure​
  - Delivering immutable infrastructure-as-code solutions using tools like Terraform, Packer, and/or CloudFormation​
  - At least one configuration management tool like Ansible, Saltstack, Puppet, or Chef​
  - Excellent skills and expertise troubleshooting networking, storage, and support services (i.e. HTTP, DHCP, DNS, NTP, NAT, etc.) of Linux systems​
  - Demonstrated experience in the setup and management of PKI infrastructure​
- Deep understanding of the entire application stack and related services​
- Worked on a team leveraging agile development practices, including stand-ups, and the creation/management of sprints, epics, and stories​

## Required Trainings

Emails sent to your Gilead email from `gxplearn@gilead.com` and `GLearn@Gilead.com` outline **mandatory** trainings that **need** to be completed.

- On completion of a training, **screenshot and save the certificate of completion**.
- A list of trainings and pending trainings can be viewed here: [GXPLearn](http://gxplearn.gilead.com/)

## Required Access

### Gilead Account Access

Access to this should be done through the first [Points-Of-Contact](#points-of-contact), via your team's lead.

- Gilead Outlook (Email)
  - Request to be added to distribution list "#Alerts_WIO_DevOps" <alerts_wio_devops@gilead.com>
- Microsoft Teams (Internal Team communication)
  - Access to *WIO Cloud DevOps* Team and the following channels
    - General Channel
    - DevOps Channel
    - Engineering (Previously Springboard) Channel
    - WIO Cloud support Channel

### Gilead Cloud Provider Access

1. Take the GXPLearn Training Course: **SOP-11390**
2. Once done, send email to first contact in [Points-Of-Contact](#points-of-contact) with the following information:
    - Screenshot of said training's certificate of completion.
    - Include the [AWS Console URL](#logging-in) from below. There are multiple environments behind Gilead SSO. This URL points to a specific one of those environments. They'll need to know which one to add you to. This may require an Active Directory sync on their end. If you're added to the wrong environment, you may get errors like this after entering your credentials but before you're prompted for MFA:
      > Multi-Factor Authentication. System error occurred, please contact IT Service Desk.
    - Request to open an IDM (Identity Management) Group Request to be added to the following groups:
        - **ENT_readonly_179886990997** (Access to read-only role)

#### Logging In

- Console: [AWS Console](https://testfedsso3.gilead.com/idp/startSSO.ping?PartnerSpId=urn:amazon:webservices)
- CLI: See [AWS-CLI](#aws-cli) section

Once set up, one should see the following roles to select from:

- `arn:aws:iam::179886990997:role/readonly`
  - **enterprise readonly role on all Gilead owned resources**
  - Can also assume into other child accounts via assuming the role, **app_readonly**, in an child account.

### GitHub Access

All of Gilead's internal infrastructure is currently managed by the repository, [ServiceTransition/CloudInfra](https://github.com/ServiceTransition/CloudInfra).

1. [Associate](https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-github-user-account/managing-email-preferences/adding-an-email-address-to-your-github-account) your GitHub profile to leverage a gilead email
2. Open a SPARC ticket under `Self Service -> Other IT Services` [link](https://sparc.service-now.com/sparc/?id=sc_cat_item&sys_id=13fa748637719b00580265e2b3990ecd&sysparm_category=6c34f86537ec57c0580265e2b3990e4b&catalog_id=3da574eb37d68200580265e2b3990ede)
3. Fill in the ticket with the information:
    - Service type: *Other Infrastructure Services*
    - Service item: *End User Service Request*
    - Additional information: See below text

    ```text
    Please route to GitHub Ops

    Please add <person name> to <github team> within ServiceTransition
    Email: <gilead email>

    Please confirm with <owner name> of <github team> to validate reason to joining said team.
    ```

4. Once you've joined **ServiceTransition**, [customize](https://docs.github.com/en/account-and-profile/managing-subscriptions-and-notifications-on-github/setting-up-notifications/configuring-notifications#customizing-email-routes-per-organization) the email notification route for ServiceTransition to the gilead email you associated earlier.
5. Invitation to the repository, **CloudInfra** should happen automatically *if you are added into a Team that CloudInfra recognizes*.
    - If not, an existing WIO Cloud DevOps Team member will grant you access via a PR.

### Jira Access

CloudInfra mainly uses the project board, [DevOps (DEV)](https://gileaddevops.atlassian.net/jira/software/c/projects/DEV/boards/83)
    - Access is gotten through email invite, obtained through the first point of contact in [Points-Of-Contact](#points-of-contact)

## Optional Access

### Gilead Network Access

Accessing on-prem services require the usage of either a **Gilead Application Delivery Infrastructure (GADI)** or a **Virtual Private Network (VPN) connection**.

#### Pre-Req

1. RSA Token
    - Setup instructions are sent to Gilead email
        - One can use RSA SecurID (GUI app) or [stoken](https://github.com/cernekee/stoken) (Unix CLI app)
        - If the attached `.sdtid` file doesn't work and you're using a non-windows machine, you may need to contact the [Help Desk](#points-of-contact).

#### GADI Access

Your initial onboarding emails should include one that helps you set up the RSA token described above and use it login to [gadi2.gilead.com](https://gadi2.gilead.com/).

The GADI2 portal is typically used to access a Windows "VDI" ("Virtual Desktop Infra"), which is useful for things like generating documentation that must be created in the right version of Microsoft Word. For example, new GxP workers must submit a CV in Word document format. The version of Word running in these VDIs can be used to generate that document.

Navigate to *Desktops* > *Gilead Virtual Desktop* to open a VDI. The team has found that Firefox works well with these virtual machines. If the portal doesn't give you this option, you can request a VDI for your account via SPARC. Historically, [Tony Munroe](#points-of-contact) has helped create these requests.

#### VPN Access
>
> Gilead contractors are not allowed to use this method

1. A Gilead email is sent, outlining instructions on how to set up VPN using **AnyConnect**
    - If one cannot install AnyConnect (i.e. if user is using linux) the system's Network Manager will suffice.
2. Follow the directions provided to import the specific config into the VPN client
3. Login using RSA token app and Gilead Credentials

### Confluence Access

[Link](https://gileaddevops.atlassian.net/wiki/spaces/CLOUDDEVOP/overview) to Cloud-DevOps Wiki Space.

- Access is granted through email invite sent by the first [Points-Of-Contact](#points-of-contact)

### Required Tooling

#### Git

- On Windows, install [Git Bash](https://gitforwindows.org/)
- On Mac/Linux, `git` is already available in the `Terminal` application.

#### Terraform

- Download [link](https://www.terraform.io/downloads.html)
  - Main version repository uses may change; refer to either the root one is working in to confirm the current Terraform Version.
  - If one wants to manage multiple versions of Terraform, [tfenv](https://github.com/tfutils/tfenv) could be used.
      [asdf](https://asdf-vm.com/) is an alternative approach.

#### AWS CLI

- Download and Install [link](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
- To provide temporary access credentials for CLI access:
  - For Ping, leverage our internal tool, [gsaml2aws](./scripts/gsaml2aws/README.md)
  - For Okta, use `[okta-awscli](https://github.com/okta-awscli/okta-awscli)`

#### New Relic

- Follow the instructions at [link](./docs/new-relic/new-relic-access.md)

## Next Steps

- Contributors [Initial Onboard Challenge](./CONTRIBUTORS.md#First-Commit-Challenge)

## Further Readings

- [FAQs](./FAQ.md)
- [Contributing Guidelines](./CONTRIBUTING.md)
- [PR Approval Process](./APPROVING.md)
- [Release Process](./RELEASE.md)
- [Terraform Deployment](./docs/terraform/terraform-development.md)
