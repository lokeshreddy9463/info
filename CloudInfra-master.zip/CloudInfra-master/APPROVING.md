# Approval Guidelines

This document describes the current guidelines for PR approvals/merges as well as the process to become an approver.

## PR Approver vs Merge Approver?

Both roles are the same in that both approve PRs, however, a Merge Approver (`mergemasters`) are individuals who have the ability to merge completed PRs. *Anyone who has access to CloudInfra can approve a PR*, so long as they follow the criteria mentioned [below](#guidelines-for-merge-approvals).

## Becoming a Merge Approver

In order to become a Merge Approver, one needs to be added to the repository as a qualified user to merge into `master`. This is handled via code in `env/prod/github/servicetransition`. The **minimum** expectations that a merge approver needs to meet are:
1. Has historically reviewed PRs in the past and has provided **constructive** feedback
1. Familiarity with CloudInfra's Contribution [policy](./CONTRIBUTING.md) and approval [policy](#guidelines-for-merge-approvals)
1. Understands that *they will be the point of contact* for their team to be approached for PR approvals and merges

If a person meets these criteria, the following should be done:
1. Open a PR to add said person as a merge approver in  `env/prod/github/servicetransition` for CloudInfra
1. **Attend the next upcoming WIO Cloud DevOps Office Hours with another team lead**, which are weekly on Fridays from 10am - 11am PST.
1. Once an agreement has been met and all existing Merge Approvers approve the additional Merge Approver, the PR can proceed to apply and be merged.

## Guidelines for Merge Approvals

1. Code is `fixedup` to a **reasonable** number of *meaningful* commits.
1. Commit messages, PR Title and Description are meaningful
1. Proof of changes are included (where applicable)
1. Explain any `tfsec` failures. See our [`tfsec` readme](tests/tfsec/README.md) for more information.
1. Alphanumeric lists are sorted appropriately
1. Not Opinionated
1. YAGNI. (You Ain't Gonna Need It)
1. D.R.Y (Don't Repeat Yourself)
1. We're in this together now.
1. Have Fun
1. Be Creative
