import json


def lambda_handler(event, context):
    # if event['request']['userAttributes']['given_name'] == 'Austin':
    #    raise Exception('User is not a member of AD group APP_BIOINFO_DATA_HUB.')

    if "custom:GROUP_MEMBER" not in event["request"]["userAttributes"]:
        raise Exception("User is not a member of AD group APP_BIOINFO_DATA_HUB.")

    if (
        event["request"]["userAttributes"]["custom:GROUP_MEMBER"]
        != "APP_BIOINFO_DATA_HUB"
    ):
        raise Exception("Cannot authenticate using AD group APP_BIOINFO_DATA_HUB.")

    # Return to Amazon Cognito
    return event
