# Python Contribution Standards

> “Indeed, the ratio of time spent reading versus writing is well over 10 to 1. We are constantly reading old code as part of the effort to write new code. ...[Therefore,] making it easy to read makes it easier to write.”

Robert C. Martin, Clean Code: A Handbook of Agile Software Craftsmanship

## Document Purpose

There is no debate about the usefulness of readable code formatting. However there are many popular opinions on how code formatting shall be implemented and enforced.

This document aims to present the alternatives and propose coding guidelines. 

## Table of Contents

* [Objectives](#guideline-objectives)
* [Python Enhancement Proposals](#python-enhancement-proposals)
* [Python Organizations](#python-organizations)
* [Alternatives](#notable-alternatives)
* [Recommendations](#recommendations)
* [Sources](#sources)
* [Definitions](#key-definitions)

## Guideline Objectives

Stating why we are adopting and enforcing guidelines should be documented. 

Thus, our objectives for defining and enforcing guidelines are:

1. Ease of readability 
1. Ease of contribution
1. Ease of future maintenance
1. Reasonably acceptable
1. Implemented through pre-commit activies
1. Enforced through CI

Additionally, it is important to call out code formatting items not under consideration:

1. Code Complexity
1. Code Performance
1. Code Security
1. Code Coverage
1. pre-commit hooks in CVS

## Python Enhancement Proposals

Within the @psf and hosted at [python.org](https://python.org) are Python Enhancement Proposals (PEP). 

[PEP8](https://www.python.org/dev/peps/pep-0008/) is the Style Guide for Python Code which forms the basis of our style guidelines.

Along with PEP8, [PEP 257](https://www.python.org/dev/peps/pep-0257/) is concerned with docstring conventions which do apply to our work.

## Python Organizations

### Python Code Quality Authority (PYcQA)

PYcQA is the [Python Code Quality Authority](https://github.com/PyCQA) PYcQA is an organization for code quality tools (and plugins) for the Python programming language.

PYcQA has 28 repositories, including the following curated list:

* [flake8](https://github.com/PyCQA/flake8) is a python tool that glues together 
	- [pycodestyle](https://github.com/PyCQA/pycodestyle) is a simple Python style checker in one Python file
	- [pyflakes](https://github.com/PyCQA/pyflakes) is simple program which checks Python source files for errors.
	- [mccabe](https://github.com/PyCQA/mccabe)
	- "and third-party plugins to check the style and quality of some python code."
* [isort](https://github.com/PyCQA/isort) is a Python utility / library to sort imports.
* [pylint](https://github.com/PyCQA/pylint) is a static code analysis tool which looks for programming errors, helps enforcing a coding standard, sniffs for code smells and offers simple refactoring suggestions.

Note: `pycodestyle` was formerly known as `pep8` until [this](https://github.com/PyCQA/pycodestyle/issues/466)

### Python Software Foundation (PSF)

The [Python Software Foundation](https://github.com/psf) stated purpose is "to promote, protect, and advance the Python programming language." 

Among the 18 repositories, the below is a curated list of relevant modules.

* [black](https://github.com/psf/black) - self-titled as the "uncompromising Python code formatter".

## Notable Alternatives

[autopep8](https://github.com/hhatto/autopep8) A tool that automatically formats Python code to conform to the PEP 8 style guide.
[yapf](https://github.com/google/yapf) Takes a different approach to python code linting using the [clang-format](https://clang.llvm.org/docs/ClangFormat.html)

## Notable flake8 extensions

[flake8-black](https://github.com/peterjc/flake8-black)
[flake8-requirements](https://github.com/Arkq/flake8-requirements)
[flakei-isort](https://github.com/gforcada/flake8-isort)

## Critical Analysis

There is overlap between many of these tools. 

### `flake8`
Includes `pycodestyle` for opinionated checking and `pyflakes` for errors. `pyflakes` promises never to complain about style.
Intentionally `IGNORE`s [controversial PEP8 rules](https://github.com/PyCQA/flake8/blob/master/src/flake8/defaults.py#L15) here.

### `pylint`

* Focused on per-file syntax errors only. 
* This makes it fast, unopinionated but limited in capabilities. 
* Users are directed towards `flake8` with `pycodestyle` for stylistic and DAST capabilities.

### `PEP8`

PEP8 is a rather long document; the cognitive load required for adherence is too high. Automated 
Not all PEP8 standard are agreeable.

### `black`

Black is the uncompromising Python code formatter. By using it, you agree to cede control over minutiae of hand-formatting. In return, Black gives you speed, determinism, and freedom from pycodestyle nagging about formatting. You will save time and mental energy for more important matters.

Blackened code looks the same regardless of the project you're reading. Formatting becomes transparent after a while and you can focus on the content instead.

### Using `black` and `flake8` together

The following contradictions are known and need to be dealt with to avoid contradictions:

`flake8` Line Break rules with binary operators [W503](https://www.flake8rules.com/rules/W503.html) and [W504](https://www.flake8rules.com/rules/W504.html)

`black` has a default `max-line-length=88`. To accomodate this, it is recommended that `flake8` be configured to allow up to a max line of 88.

## Recommendations

1. Use PEP8 and PEP257 as the basis of our styleguide.
1. Loosely couple with the PYcQA org suite of tools for longevity.
1. Users should execute `black`, `isort` and `flake8` as pre-commit activities. 
1. Use `isort`, `black` and `flake8` in check mode only in CI with `tox`

## Sources

* [Curated List of Flake8 Extensions](https://github.com/DmytroLitvinov/awesome-flake8-extensions)
* [Why you should use black](http://www.locallyoptimal.com/blog/2019/08/23/why-you-should-use-black-for-your-python-style-linting/)
* [Django DEP for black adoption](https://github.com/django/deps/blob/main/accepted/0008-black.rst)
* [Building a bikeshed](https://bikeshed.com/)
* [Barry Warsaw's Styleguide](https://barry.warsaw.us/software/STYLEGUIDE.txt)
* [Unpopular opinion on black](https://luminousmen.com/post/my-unpopular-opinion-about-black-code-formatter)
* [Using black and flake8 in tandem](https://sbarnea.com/lint/black/)

## Key Definitions:

* SAST: Static Analysis Software Testing
* DAST: Dynamic Analysis Software Testing
* Linting: Lint, or a linter, is a static code analysis tool used to flag programming errors, bugs, stylistic errors and suspicious constructs.
* Camel case (sometimes stylized as camelCase or CamelCase; also known as camel caps or more formally as medial capitals) is the practice of writing phrases without spaces or punctuation, indicating the separation of words with a single capitalized letter, and the first word starting with either case.
* Cargo Cult: A indigenist millenarian belief system in which adherents perform rituals which they believe will cause a more technologically advanced society to deliver goods.
