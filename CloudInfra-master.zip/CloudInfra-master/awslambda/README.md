# Lambdas

This document goes over the AWS Lambdas that are sourced in this repository as well as workflows, publishinging, and CI/CD usage.

## Table of Contents
- [Lambda Development](#how-to-develop-a-lambda-function)
- [Lambda Contribution Workflow](#lambda-contribution-workflow)
- [Libraries and Tools](#libraries-and-tools)
- [CI/CD Usage](#cicd-usage)
- [Coding Standards](./STANDARDS.md)
- [FAQ](../FAQ.md)

## How to Develop a Lambda Function

Below is the process for creating, testing, and publishing lambdas for this repo. This shared process will align everyone's development processes, allows for multiple opportunities to verify your outputs, and encourages healthy PR reviews.

Start your development locally, doing as much testing as possible. When youre ready to move from unit testing to integration into a true lambda function, you will publish to a dev s3 bucket and deploy the lambda for testing in a lower environment. Once it works as expected, you will merge your lambda and then reference the s3 object version id with your terraform lambda resource definition and begin the promotion process.

1. Create a branch based on a Jira issue and name it: `<your-initials>/<jira proj initials>-<issue-#>`. ex: `dm/EM-7` which refers to [this issue](https://gileaddevops.atlassian.net/browse/EM-7).
1. Develop your Lambda and unit tests locally.
1. Create a PR against master.
1. Publish to S3 using [PR comments](../.github/workflows/lambda-build.yml). By commenting "build <path_to_lambda_folder>", it will run the build process and output the zip file to all the `gilead-aws-devops-lambda-` buckets.
1. Provide your new S3 object version id to the Terraform `aws_lambda_function` resource ([example](https://github.com/ServiceTransition/CloudInfra/pull/87/commits/086d4b292bf77aaf6af82a78b6981c90c312d23a)). Alternatively, if your function is part of a module, use a module variable for the object ID, so that versioned releases of the module can roll out updates as necessary.
1. Validate working as expected; if not, repeat the steps above but you can re-use the same PR.

### Leveraging Docker

In most cases, leveraging a container to perform development can ease the pain on issues that can occur later in the CI pipeline or during deployment.

From a Mac, installing Docker `brew cask install docker` and running the container with a volume mount to the working git directory allows changes and testing to be done directly from the container.

`docker run -it lambci/lambda:${tag} /bin/sh`

[Here](https://hub.docker.com/r/lambci/lambda) on Docker Hub is where the lambda build images for Docker can be found.

### Storing Secrets

Lambda secrets are stored in AWS Systems Manager Parameter Store with the following naming convention:

`/${env}/lambda/${lambda_name}/${key_name}`

(e.g. `/dev/lambda/asg_ebs_attach/acct-id`)

## Libraries and Tools

While there are different languages that AWS Lambda supports using (Node.js, Go, Python, etc), a majority of the lambdas that the DevOps team uses leverage **Python**. Below are all of the standards and requirements we require when using said language.

### Python

#### Required Python Versions
**At least one** of the following Python versions are required to be tested and verified:
- 3.7
- 3.8

These versions will be used in the automated unit testing that will occur in new PRs that make new changes in the `awslambda` folder.

#### Required Python Libraries
- boto3
- moto
- pytest
- tox

#### Standard Python Directory

Below describes the required files and directories for a Python lambda. Note that this tree is taken from the perspective of looking at a lambda in relation to the repository root directory.

```
awslambda/
|
|-- <teamname>/
|    |
|    |-- <lambda_name>/
|    |    |-- .python-version
|    |    |
|    |    |-- setup.py
|    |    |
|    |    |-- tox.ini
|    |    |
|    |    |-- requirements.txt
|    |    |
|    |    |--- tests/
|    |    |   |
|    |    |   |-- __init__.py
|    |    |   |
|    |    |   |-- test_<function>.py
|    |    |
|    |    |--- <lambda_name>/
|    |    |   |
|    |    |   |-- <lambda_name>.py
```

- `python-version`: **important** [referenced for publishing](../scripts/lambda-build.sh#L45a)
- `tox.ini`: Configuration for `tox` CI to leverage
- `<lambda_name>/`: directory containing the lambda source code; should be replaced by the name of the lambda itself.
- `test_<function>.py`: a python script that is in the `tests` folder that will be invoked when using tox. Replace `<function>` with a suitable name (i.e. `test_function.py`)

#### Setup.py or requirements.txt

The automated script will check for the presence of a `setup.py` in the Lambdas' folder (you can optionally include a `setup.cfg`). If there is no `setup.py`, you can include a `requirements.txt` file, and the zipfile will consist of those installed libraries and any `.py` files at the top.

*IMPORTANT* - If you use a `setup.py` file, you will be expected to give your package a name. The name *MUST* match the `lambda_name` *EXACTLY*. The `lambda-build.sh` script will expect a zipfile that starts with that exact name in order to upload it to S3. For instance, if you put your Lambda in `awslambda/derpity_derp`, your packages' name in `setup.py` or `setup.cfg` MUST equal `derpity_derp`.

#### Unit Testing

All python lambdas are required to have some form of unit testing created for said lambda. These tests will be leveraged in a CI job where any new changes to a lambda will have these unit tests automatically ran. As mentioned above, these tests should lie in the `tests` directory.

We currently leverage `pytest` and `tox` to perform these unit tests. More information on [pytest](https://docs.pytest.org/en/6.2.x/) and [tox](https://tox.readthedocs.io/en/latest/index.html).

#### pytest

In order to use pytest, make sure to abide by the following rules:
1. Create a file in `tests/` called `test_functionName.py` (replacing **functionName** with a name of your choice)
2. In this file, create python functions that are prefixed by `test_`:

```python
def test_sampletest():
    assert 1 == 1
```

> These functions do not have to end with `assert` statements; they can be any generic Python statement that returns a value that can be interpreted as valid. However, best practice is to use an `assert` statement to match your test case. Also, consider limiting each test to a single `assert` statement for atomicity. If you need to run the same test against multiple sets of parameters, consider using the [parametrize decorator](https://docs.pytest.org/en/6.2.x/parametrize.html).

#### tox

tox helps create virtual environments and run unit tests on python code without yourself managing these environments. In our case, we combine `pytest` with `tox` to create a streamlined way of running isolated unit tests.

To leverage tox, keep in mind of the following:
1. Configure `tox.ini` in the root dir of the python project, making sure to specify pytest as a dependancy (along with any other deps)

A baseline `tox.ini` can be found [here](./templates/python/tox.ini.tpl).

#### Leveraging Unit Tests

##### Manual

1. Create a new virtual environment that has tox installed
2. Navigate to the python project root and run `tox`

##### Automated

1. The CI will automatically run these test through [this](../.github/workflows/lambda_tests.yml) workflow. All messages and outputs can be found in that workflow's job logs in GitHub Actions.

## CI/CD Usage

## Linting

All lambdas that land in `awslambda` are subjected to a global linting process. This is to ensure proper code format and standard practices being upheld. For details on this standard, refer to [STANDARDS.md](./STANDARDS.md) and [setup.cfg](./setup.cfg).

### py38
By default, the CI will lint your code automatically using python 3.8 and the following libraries:

```
isort==5.9.2
black==22.3.0
flake8==3.9.2
click==8.1.2
```

### py37

If a lambda is written in this version, in order for the CI to pick up your lambda for proper linting, the following config **must** be added to your `tox.ini`:

```
[testenv:py37-cilinter]
deps =
	black==22.3.0
	flake8==3.9.2
	isort==5.9.2
	click==8.1.2
commands =
	isort . --check-only
	black . --check
	flake8 .
```

### User Specific Exceptions

If a developer has additional linting configuration that **compliments and abides** the global standard, the following should be defined the following:

1. `tox.ini`
```
[testenv:py37-cilinter] # change py37 to be py38 if your python is 3.8
deps =
	black==22.3.0
	flake8==3.9.2
	isort==5.9.2
	click==8.1.2
commands =
	isort . --check-only
	black . --check
	flake8 .
```

2. `setup.cfg`
- Additional configuration for either `isort`, `black` and `flake8`

An example of what this looks like can be found in this python package [root](./devops/aws_guardduty)

### Building the Lambda

Currently, there are two supported methods that one can use to build lambdas:

#### Automated

Your code can be built and published to a versioned s3 bucket using a [github action build command](../.github/workflows/lambda-build.yml).

**Comment Format:**

```
build <build directory> <buckets space separated>
```

**Ex of PR comment:**

```
build awslambda/asg_ebs_attach bucket1 bucket2
```

The above PR comment will build the lambda bundle for asg_ebs_attach and publish it to bucket{1,2}. You can check the action log step "Run lambda-build.sh and Publish" for the package version ID. Use this to update the terraform lambda resource.

#### Manual

1. Leverage tools such as PyEnv to lock down the interpreters version.
1. Verify the proper environment variables are set.
1. Run the code using the interpreter.
