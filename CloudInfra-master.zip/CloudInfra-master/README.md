[![Terraform Validator](https://github.com/ServiceTransition/CloudInfra/actions/workflows/terraform_validator.yml/badge.svg)](https://github.com/ServiceTransition/CloudInfra/actions/workflows/terraform_validator.yml) ![Verify PR Titles](https://github.com/ServiceTransition/CloudInfra/workflows/Verify%20PR%20Titles/badge.svg)

# Gilead Cloud Infrastructure
The automation in this repository manages Gilead's AWS cloud infrastructure.

## Getting Started
1. Read the [contributing guide](CONTRIBUTING.md).
1. Check out what reviewers are looking for when [approving pull requests](APPROVING.md).
1. Follow the steps in the [onboarding guide](ONBOARDING.md). This is primarily for new members of WIO DevOps. You may not need everything in this document. Check with your manager.
1. Read through the [docs](docs/)
1. Understand how [releases are managed](RELEASE.md).
1. Take a look at the [FAQ](FAQ.md).

## Capabilities

### Manage AWS Resources
AWS resources can be created and maintained in Terraform root modules ("roots") using a combination of Atlantis and GitHub Actions Workflows. See the [Terraform Development](docs/terraform/terraform-development-v2.md) documentation.

Resources are created in AWS accounts, but accounts are also resources themselves and are managed by the same automation. They're protected by additional security called Service Control Policies (SCPs). See the [Account Creation](docs/terraform/account-creation.md) guide.

There is a migration in progress from Terraform roots in the `env/` directories to ones in the `terraform/` directories. The `terraform/` roots are managed by a newer process that's often called "v2" or "1-N" (pronounced "one to en"). 1-N is a metaphor for applying one set of resources across multiple (N) accounts. It's intended to keep parity between environments.

The 1-N system automatically creates several `pre_account` roots that define standard resources required in all accounts. It does this even for accounts whose primary roots are still defined in legacy `env/` directories. Legacy accounts have been partially migrated to the 1-N system by giving them entries in the `aws-info/aws-regional-account-info.json` file. The 1-N system detects these and creates the `pre_account` roots dynamically during releases.

### Build Amazon Machine Images
Custom Amazon Machine Images (AMIs) can be built with Packer and published to EC2. See the [Packer Development](docs/packer/packer-development.md) guide and the [DevOps Bot](docs/devops-bot.md#packer-builder) documentation.

### Set up EC2 Instances
[Terraform can create EC2 instances](#manage-aws-resources) from [AMIs](#build-amazon-machine-images). Customization like package installs and operating system configuration can be deployed to those instances with Ansible. See the [`ansible`](ansible/) directory.

### Build Container Images
Container images defined in a `Dockerfile` can be built and published to AWS ECR repositories. See the [Docker Image Publication](docs/publish-docker-images.md) guide.

### Build Lambda Function Artifacts
Custom code artifacts can be built and published to S3 and deployed into AWS Lambda functions. See the [Lambda Development](awslambda/README.md) guide and the [DevOps Bot](docs/devops-bot.md#lambda-builder) documentation.

### Aggregate Logging and Metric Data
Logs and metrics can be streamed from AWS accounts into NewRelic and used in queries and dashboards and similar tools. These features are still being developed. See the [Log Fanning](diagrams/log-fanning) diagram and the [NewRelic Access](docs/new-relic/new-relic-access.md) documentation.

### Set up Repositories for Static Site Publication
Other repositories can be set up to publish static websites to AWS S3 using templates and instructions provided here. CloudInfra doesn't do those deployments, it only provides references that help set up those repositories to do their own deployments. See the [Web Product Workflow](docs/web-product-deployment-workflow.md) and the [DevOps Bot](docs/devops-bot.md#static-sites-publishing) documentation.
