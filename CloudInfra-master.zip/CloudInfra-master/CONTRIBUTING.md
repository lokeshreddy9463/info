# Cloudinfra Contribution Guide

Thank you for your interest in contributing to the CloudInfra Repo within Gilead! This document is a set of GUIDELINES to help you get setup for CONTRIBUTION.

By participating in this project, each contributor is expected to uphold these GUIDELINES.

## Guiding Principles
- **The repository is the source of truth**
- **All deployments should be done via pull request automation, GitHubActions or scripts never via the AWS Console**

## Pull/Push Access

All contributors to CloudInfra should have **either** the following set up:
- An [SSH Key](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent) that is [SSO enabled](https://docs.github.com/en/authentication/authenticating-with-saml-single-sign-on/authorizing-an-ssh-key-for-use-with-saml-single-sign-on) with Gilead
- A [Personal Access Token](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token) (Personal Access Token) that is [SSO enabled](https://docs.github.com/en/authentication/authenticating-with-saml-single-sign-on/authorizing-a-personal-access-token-for-use-with-saml-single-sign-on) with Gilead

## Issue Tracking

The WIO DevOps Team relies on [Jira](https://gileaddevops.atlassian.net/jira/software/c/projects/DEV/boards/83) to track all issues and work performed on Agile Stories
- Issues are automatically connected to open PRs
- Issues are grouped into sprints (current priority) and backlog (not in priority)
    - Issues can span multiple issues depending on the scope of work

### Standard Development Guidelines

* `master` is our mainline branch. It is expected that `master` is stable and builds, ALWAYS
* Feature branches names should be short and descriptive. `username/JIRA-123` is an example of a feature branch name
* Long-lived branches do not exist

#### Pull Request Titles

Format of PR title: "[STATE] - [issue-#] - Title"

Where [STATE] is one of:

- [WIP] - This state indicates that work is still in progress and no review is needed yet.
- [REVIEW] - This state indicates that you would like a code review and feedback on your code.
- [READY] - This state indicates that the PR is ready to merge.

`[REVIEW] - [DEV-123] - My (80 Characters or Less) PR Title` is an example of a PR Title.

## Pull Request Body

Pull Requests body should use the [GitHub Pull Request Template](.github/pull_request_template.md).

Pull Requests quality can be enforced through [GitHub Actions](.github/workflows/pull_request_verifier.yml).

## Pull Request Approval & Merge Guidelines

1. You can not approve your own code
2. You can not merge your own code
3. All writes to `master` must be merge commits

Curious about what approvers are looking for? Checkout our page on [APPROVING](APPROVING.md) Guidelines.

### Standard Development Workflow
1. Your PR should be up-to-date with `master`
2. Another team member can approve your changes
3. You must implement your own changes, once approved
4. Another team member must merge your changes and close your PR
5. If one wishes for this change to be promoted to higher environments and the change includes resources not in terraform/lambda/ansible modules, please indicate this in the PR description.

## External Resources

Please use these EXTERNAL links for quick refrences to general SDLC methodologies

* [All About Pull Requests](https://docs.github.com/en/github/collaborating-with-issues-and-pull-requests/about-pull-requests#about-pull-requests)
* [Branching-in-a-Nutshell](https://git-scm.com/book/en/v2/Git-Branching-Branches-in-a-Nutshell)
* [Branching and Rebasing](https://git-scm.com/book/en/v2/Git-Branching-Rebasing)
* [Fixup vs. Squashing](https://git-scm.com/docs/git-rebase#_interactive_mode)
* [Git](https://git-scm.com/)
* [Squashing Commits](https://git-scm.com/book/en/v2/Git-Tools-Rewriting-History)
* [Trunk Based Development](https://trunkbaseddevelopment.com/)
